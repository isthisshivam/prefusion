import {Dimensions, PixelRatio} from 'react-native';
const {width, height} = Dimensions.get('window');
import AsyncStorage from '@react-native-community/async-storage';
import Toast from 'react-native-simple-toast';
import moment from 'moment';
export const standardDeviceSize = {width: 375, height: 667};
export default class Utility {
  static myInstance = null;

  static getInstance() {
    if (this.myInstance == null) {
      this.myInstance = new Utility();
    }
    return this.myInstance;
  }
  capitalize = str => {
    if (str) return `${str[0].toUpperCase()}${str.slice(1)}`;
    // return str[0].toUpperCase() + str.slice(1)   // without template string
  };
  async getCurrentDate() {
    return await moment.utc().format('MM/DD/YYYY,HH:mm:ssa');
  }
  async getCurrentDateUser() {
    return await moment().format('MM/DD/YYYY,HH:mm:ssa');
  }
  async getCurrentDateUserTime() {
    return await moment().format('HH:mm:ssa');
  }
  async getCurrentDateOnlyUser() {
    return await moment().format('MM/DD/YYYY');
  }

  dH = actualHeight => {
    const heightRatio = (actualHeight + 0) / standardDeviceSize.height;
    const windowHeight = Dimensions.get('window').height;
    const reqHeight = heightRatio * windowHeight;
    return reqHeight;
  };

  dW = actualWidth => {
    const widthRatio = (actualWidth + 0) / standardDeviceSize.width;
    const windowWidth = Dimensions.get('window').width;
    const reqWidth = widthRatio * windowWidth;
    return reqWidth;
  };
  inflateToast(message) {
    return Toast.show(message, Toast.SHORT);
  }

  async getStoreData(Key_to_be_fetched) {
    try {
      const value = await AsyncStorage.getItem(Key_to_be_fetched);
      if (value !== null) {
        return value;
      }
    } catch (e) {
      console.log('ERROR IN FETCHING ASYNC STORAGE DATA');
      return null;
    }
  }
  async saveSelectedDate(selected_date) {
    try {
      console.log('STORING DATA', 'DATE', 'data_to_save=', selected_date);
      await await AsyncStorage.setItem('DATE', JSON.stringify(selected_date));
    } catch (e) {
      console.log('ERROR WHILE STORING  DATA', e);
    }
  }
  async getSelectedDate() {
    try {
      const value = await AsyncStorage.getItem('DATE');
      if (value !== null) {
        return JSON.parse(value);
      }
    } catch (e) {
      console.log('ERROR WHILE STORING  DATA', e);
    }
  }

  async setStoreData(Key_to_be_paired, data_to_save) {
    try {
      console.log(
        'STORING DATA',
        Key_to_be_paired,
        'data_to_save=',
        data_to_save,
      );
      const value = await AsyncStorage.setItem(
        Key_to_be_paired,
        JSON.stringify(data_to_save),
      );
    } catch (e) {
      console.log('ERROR WHILE STORING  DATA', e);
    }
  }

  async clearDate() {
    await AsyncStorage.removeItem('DATE');
  }

  async removeStoreData(Key_to_be_removed) {
    try {
      await AsyncStorage.removeItem(Key_to_be_removed);
    } catch (e) {
      console.log('ERROR WHILE REMOVING  DATA', e);
    }
  }
  DH = () => {
    return height;
  };
  DW = () => {
    return width;
  };
  CC_BURL_WSURL(BASE_URL, API_URL) {
    return BASE_URL + API_URL;
  }
  widthToDp = number => {
    let givenWidth = typeof number === 'number' ? number : parseFloat(number);
    return PixelRatio.roundToNearestPixel((width * givenWidth) / 100);
    //will return a DPI(Density pixel ratio);
  };

  heightToDp = number => {
    let givenHeight = typeof number === 'number' ? number : parseFloat(number);
    return PixelRatio.roundToNearestPixel((width * givenHeight) / 100);
    //will return a DPI(Density pixel ratio);
  };
  async hasWhiteSpace(s) {
    //return /\s/g.test(s);
    return s.indexOf(' ') >= 0;
  }
  isEmpty(item_to_check) {
    if (
      item_to_check == null ||
      item_to_check == undefined ||
      item_to_check == '' ||
      item_to_check == 'null'
    )
      return true;
    else return false;
  }
  isEmptyString(item_to_check) {
    if (item_to_check == '') return true;
    else return false;
  }
  isEmail = email => {
    var pattern = new RegExp(
      /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i,
    );

    return pattern.test(email);
  };
  setTimeOut = (task, time) => {
    this.setTimeOut(() => {
      task;
    }, time);
  };
}
