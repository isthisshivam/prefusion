//modify date 31May 2022
import React, {useEffect, useState, useRef} from 'react';
import {
  View,
  Text,
  ImageBackground,
  TouchableOpacity,
  Image,
  ScrollView,
  FlatList,
  Pressable,
  Alert,
  BackHandler,
  TextInput,
} from 'react-native';
import {useSelector, useDispatch} from 'react-redux';
import Loader from '../../component/loader';
import ApiConstant from '../../constants/api';
import {useNavigation} from '@react-navigation/native';
import images from '../../assets/images/index';
import styles from '../MealView/style';
import globalStyles from '../../assets/globalStyles/index';
import strings from '../../constants/strings';
import colors from '../../constants/colorCodes';
import Utility from '../../utility/Utility';
import DialogView from '../../component/dialog';
import {favMealUpdateRequest} from '../../redux/action/FavMealAction';
import SelectDropdown from 'react-native-select-dropdown';
import dummyContent from '../../constants/dummyContent';
import {addMealToFavRequest} from '../../redux/action/MealAction';
import {GradientCircularProgress} from 'react-native-circular-gradient-progress';
import moment, {weekdays} from 'moment';
import Header from '../../component/headerWithBackControl';
import {
  customFoodInfoRequest,
  addCustomFoodRequest,
} from '../../redux/action/CustomFoodAction';
import {
  addMealRequest,
  mealUpdateRequest,
  mealRemoveRequest,
} from '../../redux/action/MealAction';
import {addFoodIdRequest, clearFoodId} from '../../redux/action/FoodIdAction';
import {
  addFoodToFavRequest,
  removeFoodToFavRequest,
} from '../../redux/action/AddFoodToFavAction';
import warning from '../../constants/warning';
let quantityArray = [];
var foodIdArray = [];
var payload = null;
var temp_food_id_ = null;
var temp_base_qty = null;
var today = new Date();
var date = moment(today).format('MM/DD/YYYY');
const DELETE_FOOD = 'DELETE_FOOD';
const GET_FOODS = 'GET_FOODS';
var call_type = null;
var spliceArray = null;
var clickedIndex = null;
var tempItem = null;
var selectedItemServingWeight = null;
var updatedCarbs = 0;
var updatedFat = 0;
var updatedProtein = 0;
var defaultServingWeight = 0;
var dateSelected = '';

const MealView = props => {
  const scrollRef = useRef();
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const [Loading, setLoading] = useState(false);
  const [isLoadingFav, setIsLoadingFav] = useState(false);
  const isLoading = useSelector(
    state => state.other.addCustomFoodReducer.showLoader,
  );
  const userData = useSelector(state => state.other.loginReducer.userData);
  const draftFoodsData =
    useSelector(state => state.food.addFoodIdReducer.data) || null;
  const [MEAL_ID, setMEAL_ID] = useState(null);
  const [willInflate, setWillInflate] = useState(false);
  const [selectedFoodItem, setSelectedItemFood] = useState(null);
  const [willInflateEditFood, setWillInflateEditFood] = useState(false);
  const [willInflateCopyMeal, setWillInflateCopyMeal] = useState(false);
  const [mealNum, setMealNum] = useState(0);
  const [mealName, setMealName] = useState('');
  const [mealId, setMealId] = useState('');
  const [alreadyFavorite, setAlreadyFav] = useState(false);
  const [isUpdating, setUpdating] = useState(false);
  const [mealMainArray, setMealMainArray] = useState([]);
  const [carbsArray, setcarbsArray] = useState([]);
  const [fatArray, setfatArray] = useState([]);
  const [proteinArray, setproteinArray] = useState([]);
  const [foodFatArray, setFoodFatArray] = useState([]);
  const [foodCarbsArray, setFoodCarbsArray] = useState([]);
  const [foodProteinArray, setFoodAProteinrray] = useState([]);
  const [foodId] = useState(props?.route?.params?.foodId);
  const [food_qty] = useState(props?.route?.params?.qty);
  const [userId, setUserId] = useState(userData ? userData.id : null);
  const [servingUnit, setServingUnit] = useState(null);
  const [foodPieceCount, setFoodPieceCount] = useState(0);
  const [selectedCalories, setSelectedCalories] = useState(0);
  const [customMealName, setCustomMealName] = useState('');

  const [dateValue, setDate] = useState(null);
  const [dateArray, setDateArray] = useState([]);

  if (draftFoodsData) {
    if (draftFoodsData.foodIdArrayData.length > 0) {
      let data = draftFoodsData.foodIdArrayData.toString();
      let qtyData = draftFoodsData.quantityArrayData.toString();
      let FI = props?.route?.params?.foodId;
      let QTY = props?.route?.params?.qty;
      if (global.backRoute == 'MealView') {
        payload = {
          uid: userId,
          food_id: FI.toString(),
          date: date,
          quantity: QTY.toString(),
        };
      } else {
        payload = {
          uid: userId,
          food_id: data + `,` + FI,
          date: date,
          quantity: qtyData + `,` + QTY,
        };
      }
    }
  } else {
    payload = {
      uid: userId,
      food_id: foodId,
      date: date,
      quantity: food_qty,
    };
  }

  useEffect(() => {
    const dateSet = async () => {
      let date_ = await Utility.getInstance().getSelectedDate();
      if (date_) {
        dateSelected = date_;
        setDate(date_);
      } else {
        const dateee = await Utility.getInstance().getCurrentDateOnlyUser();
        dateSelected = dateee;
        setDate(dateee);
      }
    };
    const unsubscribe = navigation.addListener('focus', () => {
      dateSet();
    });
    return () => {
      unsubscribe();
    };
  }, []);
  useEffect(() => {
    call_type = GET_FOODS;
    const unsubscribe = navigation.addListener('focus', () => {
      quantityArray = [];
      foodIdArray = [];
      getMealId();
    });
    const backHandler = BackHandler.addEventListener(
      'hardwareBackPress',
      () => true,
    );

    return () => {
      quantityArray = [];
      foodIdArray = [];
      // MEAL_ID = null;
      unsubscribe;
      backHandler;
      setMEAL_ID(null);
    };
  }, []);

  const getSetSelectedDate = async () => {
    let currentTime = await Utility.getInstance().getCurrentDateUserTime();
    return dateSelected + ',' + currentTime;
  };
  const getMealId = async () => {
    await Utility.getInstance()
      .getStoreData('MEAL_ID')
      .then(id => {
        if (id) {
          setMEAL_ID(id);
        }

        getMealDetails(payload);
      });
  };

  const getMealDetails = async api_payload => {
    let timezone =
      Platform.OS === 'android'
        ? ''
        : Intl.DateTimeFormat().resolvedOptions().timeZone;
    let payload = {
      ...api_payload,
      current_date:
        (await Utility.getInstance().getCurrentDateUser()) + ',' + timezone,
    };

    setTimeout(() => {
      dispatch(customFoodInfoRequest(payload, onS, onF));
    }, 100);
  };

  const onS = resolve => {
    const {meal, macro, favorite_meal, meal_number, date, fav_id} =
      resolve.data;
    setMealNum(meal_number);
    setMealMainArray(meal);

    fav_meal_id = fav_id;
    if (call_type == GET_FOODS) {
      meal.forEach(item => {
        quantityArray.push(item.quantity);
        foodIdArray.push(item.id);
      });
    }

    if (favorite_meal == 1) setAlreadyFav(true);
    else setAlreadyFav(false);
    setcarbsArray(macro.carbs);
    setfatArray(macro.fat);
    setproteinArray(macro.protein);
    setDateArray(date);
    setLoading(false);
  };
  useEffect(() => {
    if (dateArray.length > 0) {
      focusToCurrentDate();
    }
  }, [dateArray]);

  const focusToCurrentDate = () => {
    if (scrollRef != null && scrollRef != undefined) {
      if (scrollRef?.current) {
        if (global.weekdays.length > 0) {
          let index = 1;
          for (let i = 0; i < global.weekdays.length; i++) {
            if (dateValue == global.weekdays[i].date) {
              index = i;
            }
          }
          setTimeout(() => {
            if (index && index != 0 && index != -1)
              scrollRef?.current?.scrollToIndex({animated: true, index: index});
          }, 10);
        }
      }
    }
  };
  const scrollToIndexFailed = error => {
    const offset = error.averageItemLength * error.index;
    scrollRef?.current?.scrollToOffset({offset});
    setTimeout(
      () => scrollRef?.current?.scrollToIndex({index: error.index}),
      100,
    ); // You may choose to skip this line if the above typically works well because your average item height is accurate.
  };

  const addMealId = async () => {
    dispatch(
      addFoodIdRequest({
        foodIdArrayData: foodIdArray,
        quantityArrayData: quantityArray,
      }),
    );
    setTimeout(() => {
      navigation.navigate('AddFoods', {
        foodId: foodIdArray,
        qty: quantityArray,
      });
    }, 100);
  };
  const onF = reject => {
    Utility.getInstance().inflateToast(reject);
  };

  const addMealToFavCall = async () => {
    let payload = {
      //  date: date,
      uid: userId,
      meal_id: mealId,
      favorite: '1',
      food_id: foodIdArray.toString(),
      quantity: quantityArray.toString(),
      favorite_seperation: true,
    };
    setIsLoadingFav(true);
    dispatch(addMealToFavRequest(payload, onAddmealSuc, onAddmealFailure));
  };

  const onAddmealSuc = resolve => {
    setIsLoadingFav(false);
    setWillInflate(false);
    setTimeout(() => {
      dispatch(clearFoodId());
      navigation.navigate('Home');
      clearFavMealGlobalVariableDetails();
    }, 300);
  };

  const onAddmealFailure = reject => {
    setIsLoadingFav(false);
    Utility.getInstance().inflateToast(reject);
    setTimeout(() => {
      navigation.navigate('Home');
      clearFavMealGlobalVariableDetails();
    }, 300);
  };

  const backPress = () => {
    navigation.goBack();
  };

  const onDonePress = () => {
    if (MEAL_ID) {
      if (global.is_fav_meal) {
        favMealUpdate();
      } else {
        mealUpdate();
      }
    } else {
      createMeal();
    }
  };
  const onDeleteMealPress = () => {
    let payload = {
      uid: userId,
      meal_id: MEAL_ID,
    };
    setLoading(true);
    dispatch(mealRemoveRequest(payload, onMealRemoveS, onMealFailure));
  };
  const onMealRemoveS = async resolve => {
    setLoading(false);
    navigation.navigate('DailyDairy');
    clearFavMealGlobalVariableDetails();
  };
  const onMealFailure = async reject => {
    setLoading(false);
    Utility.getInstance().inflateToast(reject);
  };
  const manipulateServingOnMealCreateTime = () => {
    call_type = DELETE_FOOD;
    setWillInflateEditFood(false);

    const {
      name,
      food_id,
      nf_calories,
      base_food_details,
      note,
      fiber,
      photo,
      quantity,
      calories,
      serving_weight_grams,
      measurement,
      customFood,
      image,
      id,
    } = selectedFoodItem;

    if (base_food_details != '') {
      let parsingbase_food_details = JSON.parse(base_food_details);
      payload = {
        ...selectedFoodItem,
        calories: parseFloat(selectedCalories),
        carbs: parseFloat(updatedCarbs),
        fat: parseFloat(updatedFat),
        protein: parseFloat(updatedProtein),
        base_food_details: JSON.stringify({
          base_calories: parsingbase_food_details.base_calories,
          base_carbs: parsingbase_food_details.base_carbs,
          base_fat: parsingbase_food_details.base_fat,
          base_protein: parsingbase_food_details.base_protein,
        }),
        measurement: measurement != '' ? JSON.stringify(measurement) : '',
        serving_weight_grams: serving_weight_grams,
        quantity: parseFloat(foodPieceCount),
        created_by: parseInt(userId),
        fiber: parseFloat(fiber),
        description: note,
        unit: servingUnit,
        food_id: food_id,
        name: name,
        image: image,
      };
    } else {
      payload = {
        ...selectedFoodItem,
        calories: parseFloat(selectedCalories),
        carbs: parseFloat(updatedCarbs),
        fat: parseFloat(updatedFat),
        protein: parseFloat(updatedProtein),
        base_food_details: '',
        measurement: '',
        serving_weight_grams: '',
        quantity: parseFloat(foodPieceCount),
        created_by: parseInt(userId),
        fiber: parseFloat(fiber),
        description: note,
        unit: servingUnit,
        food_id: food_id,
        name: name,
        image: image,
      };
    }
    console.log('manipulateServingOnMealCreateTime.payload===', payload);
    //  return;
    if (customFood) {
      let updated_food_id = id;

      var index = foodIdArray.indexOf(temp_food_id_);
      if (index != -1) {
        foodIdArray[index] = parseInt(updated_food_id);
      }
      payload = {
        uid: userId,
        food_id: foodIdArray.toString(),
        quantity: quantityArray.toString(),
        date: date,
      };

      getMealDetails(payload);
    } else {
      dispatch(addCustomFoodRequest(payload, onSSSSS, onFFFFF));
    }
  };

  const onSSSSS = async resolve => {
    let updated_food_id = resolve?.data?.id;

    var index = foodIdArray.indexOf(temp_food_id_);

    if (index != -1) {
      foodIdArray[index] = parseInt(updated_food_id);
    }
    payload = {
      uid: userId,
      food_id: foodIdArray.toString(),
      quantity: quantityArray.toString(),
      date: date,
    };

    getMealDetails(payload);
  };
  const onFFFFF = async reject => {
    Utility.getInstance().inflateToast(reject);
  };

  const createMeal = async () => {
    let payload = {
      uid: userId,
      food_id: foodIdArray.toString(),
      quantity: quantityArray.toString(),

      date: await getSetSelectedDate(),
      meal_name: Global,
      endpoint: ApiConstant.MEAL_ADD,
    };

    setLoading(true);
    dispatch(addMealRequest(payload, onSS, onFF));
  };
  const favMealUpdate = () => {
    setLoading(true);
    let payload = {
      uid: userId,
      food_id: foodIdArray.toString(),
      quantity: quantityArray.toString(),

      meal_id: MEAL_ID,
      fav_id: global.fav_id,
    };

    dispatch(
      favMealUpdateRequest(payload, onFavMealUpdateSucc, onFavMealUpdateFail),
    );
  };
  const onFavMealUpdateSucc = async resolve => {
    setLoading(false);
    setTimeout(() => {
      navigation.goBack();
    }, 1000);
  };
  const onFavMealUpdateFail = async reject => {
    setLoading(false);
    setTimeout(() => {
      Utility.getInstance().inflateToast(reject);
    }, 300);
  };
  const clearFavMealGlobalVariableDetails = () => {
    global.is_fav_meal = false;
    global.fav_id = null;
  };
  const mealUpdate = () => {
    setLoading(true);
    let payload = {
      uid: userId,
      food_id: foodIdArray.toString(),
      quantity: quantityArray.toString(),

      meal_id: MEAL_ID,
    };

    dispatch(mealUpdateRequest(payload, onSS, onFF));
  };
  const saveSelectedDate = async date => {
    await Utility.getInstance().saveSelectedDate(date);
  };
  const onSS = async resolve => {
    const {id, favorite} = resolve.data;
    setMealId(id);
    if (favorite == '1') setAlreadyFav(true);
    else if (favorite == '') setAlreadyFav(false);
    else setAlreadyFav(false);

    await Utility.getInstance().removeStoreData('MEAL_ID');
    setTimeout(() => {
      setLoading(false);
      dispatch(clearFoodId());
      setWillInflate(true);
    }, 100);
  };
  const onFF = reject => {
    setLoading(false);
    Utility.getInstance().inflateToast(reject);
  };
  const validateCopyAndCreateMealFirst = () => {
    var message = '';
    if (Utility.getInstance().isEmpty(mealName)) {
      message = warning.enter_name;
    } else if (
      mealName == 'Custom' &&
      Utility.getInstance().isEmpty(customMealName)
    ) {
      message = 'Please enter meal name';
    }
    if (message == '') {
      return true;
    }
    Utility.getInstance().inflateToast(message);
    return false;
  };
  const copyAndCreateMeal = async () => {
    if (validateCopyAndCreateMealFirst()) {
      setLoading(true);
      let payload = {
        uid: userId,
        food_id: foodIdArray.toString(),
        quantity: quantityArray.toString(),
        date: await Utility.getInstance().getCurrentDateUser(),
        meal_name: mealName == 'Custom' ? customMealName : mealName,
        endpoint: ApiConstant.MEAL_ADD,
      };
      dispatch(
        addMealRequest(payload, onSSCopyAndCreateMeal, onFFCopyAndCreateMeal),
      );
    }
  };

  const onSSCopyAndCreateMeal = async resolve => {
    const {id, favorite} = resolve.data;
    setMealId(id);
    if (favorite == '1') setAlreadyFav(true);
    else if (favorite == '') setAlreadyFav(false);
    else setAlreadyFav(false);
    setLoading(false);
    setWillInflateCopyMeal(false);

    setTimeout(() => {
      dispatch(clearFoodId());
      setWillInflate(true);
    }, 1000);
  };
  const onFFCopyAndCreateMeal = reject => {
    setLoading(false);
    Utility.getInstance().inflateToast(reject);
  };
  const onHeartPress = item => {
    const {favorite, id} = item.item;
    let index = item.index;
    if (mealMainArray[index].favorite == 0) {
      mealMainArray[index].favorite = 1;
      addFoodToFav(id);
    } else if (mealMainArray[index].favorite == 1) {
      mealMainArray[index].favorite = 0;
      removeFoodToFav(id);
    }
    setMealMainArray(mealMainArray);
    setUpdating(!isUpdating);
  };
  const addFoodToFav = async foodId => {
    let payload = {
      uid: userId,
      food_id: foodId,
      date: await Utility.getInstance().getCurrentDate(),
    };
    dispatch(addFoodToFavRequest(payload));
  };
  const removeFoodToFav = foodId => {
    let payload = {
      uid: userId,
      food_id: foodId,
    };
    dispatch(removeFoodToFavRequest(payload));
  };
  const onDeleteFoodPress = async item => {
    call_type = DELETE_FOOD;
    let index = item.index;
    console.log('item', JSON.stringify(item));

    const {favorite, id} = item.item;
    spliceArray = mealMainArray.filter((item, index) => {
      return item.id != id;
      return item.id != id;
    });
    foodIdArray.splice(index, 1);
    quantityArray.splice(index, 1);

    let foodIdData = foodIdArray.toString();
    let qtyData = quantityArray.toString();
    let delete_payload = {
      uid: userId,
      food_id: foodIdData,
      date: await Utility.getInstance().getCurrentDate(),
      quantity: qtyData,
    };
    if (MEAL_ID) {
      if (spliceArray) {
        setMealMainArray(spliceArray);
        if (spliceArray.length == 0) {
          mealUpdate();
          return;
        }
      }
    } else {
      if (spliceArray) {
        setMealMainArray(spliceArray);
        if (spliceArray.length == 0) {
          navigation.navigate('Home');
          clearFavMealGlobalVariableDetails();
          return;
        }
      }
    }
    setTimeout(() => {
      getMealDetails(delete_payload);
    }, 2000);
  };
  const discardAlert = () =>
    Alert.alert(
      'Discard entire Meal',
      'If you go back now, you will loose Meal that have been added.',
      [
        {
          text: 'Cancel',
          onPress: () => onCancelPress(),
          style: 'cancel',
        },
        {text: 'Discard Meal', onPress: () => onDiscardMealPress()},
      ],
    );
  const onCancelPress = () => {};
  const onDiscardMealPress = () => {
    dispatch(clearFoodId());
    setTimeout(() => {
      global.backRoute = 'AddMeal';
      backPress();
    }, 100);
  };
  const onTouchOutsideEditFood = async () => {
    await setFoodAProteinrray([]);
    await setFoodFatArray([]);
    await setFoodCarbsArray([]);
    setWillInflateEditFood(false);
  };
  const onTouchOutsideCopyMeal = async () => {
    setWillInflateCopyMeal(!willInflateCopyMeal);
  };
  useEffect(() => {
    if (selectedFoodItem) {
      onEditButtonClick(tempItem);
    }
  }, [selectedFoodItem]);

  const onSetSelectedItemPress = item => {
    const {measurement, quantity} = item;
    if (measurement != '') {
      let parsedItem = {
        ...item,
        measurement: JSON.parse(measurement),
      };
      setSelectedItemFood(parsedItem);
    } else {
      let parsedItem = {
        ...item,
        quantity: quantity,
      };
      setSelectedItemFood(parsedItem);
    }
  };
  const onEditButtonClick = async item => {
    const {
      quantity,
      serving_qty,
      measurement,
      serving_weight_grams,
      unit,
      calories,
      id,
      base_qty,
    } = item;
    temp_base_qty = base_qty;
    temp = serving_qty ? serving_qty : 1;

    defaultServingWeight = serving_weight_grams;
    if (serving_weight_grams != '' && serving_weight_grams != null) {
      if (measurement != '') {
        checkAndGetDefaultServingWeight(
          JSON.parse(measurement),
          serving_qty,
          unit,
        );
      } else {
        defaultServingWeight = 0;
        updateServingsThroughPeiceQtyBasis(quantity);
      }
    } else {
      updateServingsThroughPeiceQtyBasis(quantity);
    }
    setSelectedCalories(parseFloat(calories));
    setFoodPieceCount(quantity);
    setServingUnit(unit);
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setWillInflateEditFood(true);
    }, 500);
  };
  const checkAndGetDefaultServingWeight = (measurementData, quantity, unit) => {
    let food;
    food = measurementData.find(food => food.measure === unit);

    if (food) {
      selectedItemServingWeight = {
        serving_weight: food?.serving_weight,
        measure: unit,
      };
    } else {
      food = measurementData.find(data => data.measure.match(unit));

      selectedItemServingWeight = {
        serving_weight: food?.serving_weight,
        measure: unit,
      };
    }
    updateServingsThroughMeasurment(selectedItemServingWeight, quantity);
  };
  const updateServingsThroughPeiceQtyBasis = async updatedQty => {
    var newQ;
    if (defaultServingWeight != 0) {
      newQ = updatedQty;
    } else {
      newQ = updatedQty / temp_base_qty;
    }

    const {carbs_value, fat_value, protein_value, calories, base_food_details} =
      selectedFoodItem;

    let parsingbase_food_details = JSON.parse(base_food_details);

    await setFoodAProteinrray(
      returnBucketArray(
        Math.round(parsingbase_food_details.base_protein) * newQ,
        20,
        true,
      ),
    );

    await setFoodFatArray(
      returnBucketArray(
        Math.round(parsingbase_food_details.base_fat) * newQ,
        10,
      ),
    );

    await setFoodCarbsArray(
      returnBucketArray(
        parseFloat(Math.round(parsingbase_food_details.base_carbs) * newQ),
        20,
        true,
      ),
    );

    setSelectedCalories(
      parseFloat(newQ * Math.round(parsingbase_food_details?.base_calories)),
    );

    updatedCarbs = Math.round(parsingbase_food_details.base_carbs) * newQ;
    updatedFat = Math.round(parsingbase_food_details.base_fat) * newQ;
    updatedProtein = Math.round(parsingbase_food_details.base_protein) * newQ;
  };

  const returnBucketArray = (totalvalue, type, isProtein = false) => {
    let value = Math.round(totalvalue);

    let bucketArray = [];
    for (let i = value; i > 0; i -= type) {
      if (isProtein && i < 16) {
        if (i == 1 || i == 2) {
          break;
        }
        if (i < 7) {
          bucketArray.push(25);
          break;
        }
        if (i < 12) {
          bucketArray.push(50);
          break;
        }
        if (i < 16) {
          bucketArray.push(75);
          break;
        }
      } else if (i < (type == 20 ? 16 : 9)) {
        if (i < (type == 20 ? 6 : 4)) {
          bucketArray.push(25);
          break;
        }
        if (i < (type == 20 ? 11 : 6)) {
          bucketArray.push(50);
          break;
        }
        if (i < (type == 20 ? 16 : 9)) {
          bucketArray.push(75);
          break;
        }
      }
      bucketArray.push(100);
    }

    return bucketArray;
  };
  const updateQty = qty => {
    quantityArray[clickedIndex] = qty;
  };

  const updateServingsThroughMeasurment = (selected_Item, foo_piece_Count) => {
    const {
      carbs_value,
      fat_value,
      protein_value,
      calories,
      base_food_details,
      base_qty,
      quantity,
      serving_qty,
      serving_weight_grams,
    } = selectedFoodItem;
    let parsingbase_food_details = JSON.parse(base_food_details);

    const value =
      selected_Item?.measure == 'g'
        ? (1 * foo_piece_Count) / defaultServingWeight
        : parseFloat(selected_Item?.serving_weight / serving_weight_grams) *
          (serving_qty / base_qty);

    setFoodAProteinrray(
      returnBucketArray(
        Math.round(parsingbase_food_details.base_protein) * value,
        20,
        true,
      ),
    );
    setFoodFatArray(
      returnBucketArray(
        Math.round(parsingbase_food_details.base_fat) * value,
        10,
      ),
    );
    setFoodCarbsArray(
      returnBucketArray(
        Math.round(parsingbase_food_details.base_carbs) * value,
        20,
        true,
      ),
    );
    setServingUnit(selected_Item?.measure);
    updatedCarbs = Math.round(parsingbase_food_details.base_carbs) * value;
    updatedFat = Math.round(parsingbase_food_details.base_fat) * value;
    updatedProtein = Math.round(parsingbase_food_details.base_protein) * value;

    setSelectedCalories(
      parseFloat(parsingbase_food_details?.base_calories * value),
    );
  };

  const EditFoodModal = () => {
    return (
      <DialogView
        onTouchOutside={() => console.log('onTouchOutside')}
        willInflate={willInflateEditFood}
        onBackPress={() => setWillInflateEditFood(false)}
        children={EditModalContent()}></DialogView>
    );
  };
  const EditModalContent = () => {
    return (
      <View>
        <View
          style={{
            height: 40,
            flexDirection: 'row',
            width: '100%',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}>
          <TouchableOpacity onPress={() => onTouchOutsideEditFood()}>
            <Image
              style={globalStyles.backimgregister}
              source={images.FAVORITE.ARROW}></Image>
          </TouchableOpacity>
          <Text
            style={{
              alignSelf: 'center',
              textAlign: 'center',
              fontFamily: 'Poppins-SemiBold',
              color: colors.black,
              fontSize: 20,
            }}>
            Edit Food
          </Text>
          <View
            style={{
              height: 20,
              width: 20,
              marginHorizontal: 20,
            }}></View>
        </View>
        <View
          style={{
            marginTop: 7,
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <View
            style={[
              styles.addfoodcn,
              {
                flexDirection: 'row',
                justifyContent: 'space-between',
                width: '100%',
              },
            ]}>
            <View style={{flex: 0.56}}>
              <Text style={[styles.why_heading, globalStyles.font20]}>
                {selectedFoodItem?.name}
              </Text>
              <SelectDropdown
                data={dummyContent.piece}
                onSelect={(selectedItem, index) => {
                  console.log('selectedItemshivamsaini', selectedItem);
                  setFoodPieceCount(selectedItem);
                  updateQty(selectedItem);
                  selectedFoodItem.serving_qty = selectedItem;
                  if (selectedFoodItem?.measurement != '') {
                    updateServingsThroughMeasurment(
                      selectedItemServingWeight,
                      selectedItem,
                    );
                  } else {
                    updateServingsThroughPeiceQtyBasis(selectedItem);
                  }
                }}
                defaultButtonText={foodPieceCount}
                //defaultButtonText={foodPieceCount + servingUnit}
                buttonTextAfterSelection={(selectedItem, index) => {
                  return selectedItem;
                }}
                rowTextForSelection={(item, index) => {
                  return item;
                }}
                renderDropdownIcon={() => {
                  return (
                    <Image
                      style={{
                        height: 12,
                        width: 12,
                        resizeMode: 'contain',
                        //   transform: [{rotate: '270deg'}],
                      }}
                      source={images.SIGNUP.DOWN_ARROW}
                    />
                  );
                }}
                buttonStyle={styles.dropdownSmall4BtnStyle}
                buttonTextStyle={styles.dropdown4BtnTxtStyle}
                dropdownIconPosition={'right'}
                dropdownStyle={styles.dropdown4DropdownStyle}
                rowStyle={styles.dropdown4RowStyle}
                rowTextStyle={styles.dropdown4RowTxtStyle}
              />
            </View>
            <View style={{flex: 0.42, alignItems: 'flex-end'}}>
              <View style={styles.progressbar}>
                <GradientCircularProgress
                  startColor={colors.primary}
                  middleColor={colors.secondary}
                  endColor={colors.primary}
                  size={47}
                  emptyColor={colors.black}
                  progress={70}
                  style={{backgroundColor: 'black'}}
                  strokeWidth={6}>
                  <Text style={styles.lbs}>{parseInt(selectedCalories)}</Text>
                </GradientCircularProgress>
                <Text
                  style={[
                    //styles.bucketSize,
                    globalStyles.mt_10,
                    // styles.headingtextBlack,
                    {fontSize: Utility.getInstance().dH(10)},
                  ]}>
                  {strings.calories}
                </Text>
              </View>
            </View>
          </View>
          {selectedFoodItem?.measurement != '' && (
            <View
              style={[
                {
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  width: '100%',
                },
              ]}>
              <View style={{flex: 0.6}}>
                <SelectDropdown
                  data={
                    selectedFoodItem?.measurement != ''
                      ? selectedFoodItem?.measurement
                      : []
                  }
                  onSelect={(selectedItem, index) => {
                    console.log(selectedItem);
                    setServingUnit(selectedItem.measure);

                    selectedFoodItem.base_qty = selectedItem?.qty;
                    selectedItemServingWeight = {
                      serving_weight: selectedItem?.serving_weight,
                      measure: selectedItem.measure,
                    };
                    console.log(
                      'updateServingsThroughMeasurment.selectedItemtotalweight==',
                      selectedItem?.serving_weight,
                    );
                    updateServingsThroughMeasurment(
                      selectedItemServingWeight,
                      foodPieceCount,
                      'EDIT',
                    );
                  }}
                  defaultButtonText={servingUnit}
                  buttonTextAfterSelection={(selectedItem, index) => {
                    return selectedItem.measure;
                  }}
                  rowTextForSelection={(item, index) => {
                    return item?.measure;
                  }}
                  renderDropdownIcon={() => {
                    return (
                      <Image
                        style={{
                          height: 12,
                          width: 12,
                          resizeMode: 'contain',
                          //   transform: [{rotate: '270deg'}],
                        }}
                        source={images.SIGNUP.DOWN_ARROW}
                      />
                    );
                  }}
                  buttonStyle={styles.dropdownSmall4BtnStyle}
                  buttonTextStyle={styles.dropdown4BtnTxtStyle}
                  dropdownIconPosition={'right'}
                  dropdownStyle={styles.dropdown4DropdownStyle}
                  rowStyle={styles.dropdown4RowStyle}
                  rowTextStyle={styles.dropdown4RowTxtStyle}
                />
              </View>
            </View>
          )}

          <View style={styles.favmealsCC}>
            <View style={styles.mealc}>
              <View style={{flex: 1, marginRight: 10}}>
                <View style={[globalStyles.flex_row, {marginRight: 10}]}>
                  <ImageBackground
                    source={{uri: selectedFoodItem?.image}}
                    borderRadius={10}
                    style={styles.mealimg_s}></ImageBackground>
                  <View style={{marginLeft: 20}}>
                    {foodCarbsArray.length > 0 && (
                      <View style={styles.mealinnerc}>
                        <View style={{flex: 0.4}}>
                          <Text
                            style={[
                              styles.forgot_pass_heading,
                              styles.whydesc_new,
                              styles.red,
                            ]}>
                            {`Carbs:`}
                          </Text>
                        </View>
                        <View
                          style={{
                            flex: 0.6,
                            height: 50,
                            marginRight: 10,
                          }}>
                          <FlatList
                            data={foodCarbsArray}
                            horizontal
                            extraData={foodCarbsArray}
                            contentContainerStyle={{alignItems: 'center'}}
                            showsHorizontalScrollIndicator={false}
                            renderItem={({item}) =>
                              rendeCarbsItem(item)
                            }></FlatList>
                        </View>
                      </View>
                    )}
                    {foodFatArray.length > 0 && (
                      <View style={styles.mealinnerc}>
                        <View style={{flex: 0.4}}>
                          <Text
                            style={[
                              styles.forgot_pass_heading,
                              styles.whydesc_new,
                              styles.orange,
                            ]}>
                            {`Fats:`}
                          </Text>
                        </View>
                        <View style={{flex: 0.6, height: 50, marginRight: 10}}>
                          <FlatList
                            data={foodFatArray}
                            horizontal
                            extraData={foodFatArray}
                            contentContainerStyle={{alignItems: 'center'}}
                            showsHorizontalScrollIndicator={false}
                            renderItem={({item}) =>
                              rendeFatItem(item)
                            }></FlatList>
                        </View>
                      </View>
                    )}
                    {foodProteinArray.length > 0 && (
                      <View style={styles.mealinnerc}>
                        <View
                          style={{
                            flex: 0.4,
                          }}>
                          <Text
                            style={[
                              styles.forgot_pass_heading,
                              styles.whydesc_new,
                              styles.green,
                            ]}>
                            {`Protein:`}
                          </Text>
                        </View>
                        <View
                          style={{
                            flex: 0.6,
                            height: 50,
                            marginRight: 10,
                          }}>
                          <FlatList
                            data={foodProteinArray}
                            horizontal
                            extraData={foodProteinArray}
                            contentContainerStyle={{alignItems: 'center'}}
                            showsHorizontalScrollIndicator={false}
                            renderItem={({item}) =>
                              rendeProteinItem(item)
                            }></FlatList>
                        </View>
                      </View>
                    )}
                  </View>
                </View>
              </View>
            </View>
          </View>

          <TouchableOpacity
            onPress={() => manipulateServingOnMealCreateTime()}
            style={[
              globalStyles.button_secondary,
              globalStyles.center,
              globalStyles.button,
              globalStyles.mt_30,
            ]}>
            <Text style={globalStyles.btn_heading_black}>ACCEPT CHANGES</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => onTouchOutsideEditFood()}
            style={[
              globalStyles.button_secondarywithoutBlackBack,
              globalStyles.center,
              globalStyles.button,
              globalStyles.mt_30,
            ]}>
            <Text style={globalStyles.btn_heading_black}>CANCEL</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };
  const CopyMealModal = () => {
    return (
      <DialogView
        onTouchOutside={() => console.log('onTouchOutside.CopyMealModal')}
        willInflate={willInflateCopyMeal}
        onBackPress={() => setWillInflateCopyMeal(false)}
        dialog_Container={globalStyles.dialog_Container_a_bit_large}
        children={CopyMealContent()}></DialogView>
    );
  };
  const CopyMealContent = () => {
    return (
      <View>
        <View
          style={{
            height: 40,
            flexDirection: 'row',
            width: '100%',
            alignItems: 'center',
            backgroundColor: 'transparent',
            justifyContent: 'space-between',
          }}>
          <TouchableOpacity onPress={() => onTouchOutsideCopyMeal()}>
            <Image
              style={globalStyles.backimgregister}
              source={images.FAVORITE.ARROW}></Image>
          </TouchableOpacity>
          <Text
            style={{
              alignSelf: 'center',
              textAlign: 'center',
              fontFamily: 'Poppins-SemiBold',
              color: colors.black,
              fontSize: 16,
            }}>
            Copy to Current Day
          </Text>
          <View style={globalStyles.backimgregister}></View>
        </View>
        <View
          style={{
            marginTop: 7,
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          {CopyMealView()}

          <View style={[globalStyles.mt_30, globalStyles.width_100_percent]}>
            <Text style={[globalStyles.input_heading, {color: colors.black}]}>
              {strings.nameMeal}
            </Text>

            <SelectDropdown
              data={dummyContent.food}
              onSelect={(selectedItem, index) => {
                console.log('selectedItem.mealname==', selectedItem);
                setMealName(selectedItem);
              }}
              defaultButtonText={mealName}
              buttonTextAfterSelection={(selectedItem, index) => {
                return selectedItem;
              }}
              rowTextForSelection={(item, index) => {
                return item;
              }}
              renderDropdownIcon={() => {
                return (
                  <Image
                    style={{
                      height: 12,
                      width: 12,
                      resizeMode: 'contain',
                      //   transform: [{rotate: '270deg'}],
                    }}
                    source={images.SIGNUP.DOWN_ARROW}
                  />
                );
              }}
              buttonStyle={styles.dropdownFull4BtnStyle}
              buttonTextStyle={styles.dropdown4BtnTxtStyle}
              dropdownIconPosition={'right'}
              dropdownStyle={styles.dropdown4DropdownStyle}
              rowStyle={styles.dropdown4RowStyle}
              rowTextStyle={styles.dropdown4RowTxtStyle}
            />
            {mealName == 'Custom' && (
              <TextInput
                value={customMealName}
                onChangeText={text => setCustomMealName(text)}
                style={styles.input}
              />
            )}
          </View>
          <TouchableOpacity
            onPress={() => copyAndCreateMeal()}
            style={[
              globalStyles.button_secondary,
              globalStyles.center,
              globalStyles.button,
              globalStyles.mt_30,
            ]}>
            <Text style={globalStyles.btn_heading_black}>ADD</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => onTouchOutsideCopyMeal()}
            style={[
              globalStyles.button_secondarywithoutBlackBack,
              globalStyles.center,
              globalStyles.button,
              globalStyles.mt_30,
            ]}>
            <Text style={globalStyles.btn_heading_black}>CANCEL</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  const HeaderInfo = () => {
    return (
      <View
        style={[
          globalStyles.center,
          globalStyles.padding_30_hor,
          globalStyles.flex_row,
          globalStyles.justifyContent_space_between,
          {marginTop: 12},
        ]}>
        {MEAL_ID ? (
          <Text
            style={[
              styles.why_heading,
              globalStyles.font25,
              globalStyles.mt_30,
            ]}>
            {Global}
          </Text>
        ) : (
          <View>
            <Text style={[styles.why_heading, styles.font30]}>
              {`Meal ` + mealNum}
            </Text>
            <Text
              style={[
                globalStyles.textAlignStart,
                styles.white,
                globalStyles.font17,
              ]}>
              {Global}
            </Text>
          </View>
        )}
        <View style={globalStyles.alignItems_c}>
          <TouchableOpacity
            onPress={() => [
              (global.backRoute = 'MealView'),
              MEAL_ID ? [(call_type = GET_FOODS), addMealId()] : addMealId(),
              setDate(null),
              (dateSelected = null),
            ]}
            style={styles.minuscBig}>
            <Image style={styles.codeimage} source={images.SIGNUP.PLUS}></Image>
          </TouchableOpacity>
          <Text
            style={[
              globalStyles.textAlignStart,
              styles.white,
              globalStyles.font17,
              globalStyles.mt_10,
            ]}>
            {strings.addfoods}
          </Text>
        </View>
      </View>
    );
  };
  const rendeFatItem = item => {
    if (item == 100) {
      return (
        <Image
          style={styles.smallbucket}
          source={images.FAT_IMAGE.ORANGE_100}></Image>
      );
    } else if (item == 75)
      return (
        <Image
          style={styles.smallbucket}
          source={images.FAT_IMAGE.ORANGE_75}></Image>
      );
    else if (item == 50)
      return (
        <Image
          style={styles.smallbucket}
          source={images.FAT_IMAGE.ORANGE_50}></Image>
      );
    else if (item == 25)
      return (
        <Image
          style={styles.smallbucket}
          source={images.FAT_IMAGE.ORANGE_25}></Image>
      );
  };
  const rendeProteinItem = item => {
    if (item == 100) {
      return (
        <Image
          style={styles.smallbucket}
          source={images.PROTEIN_IMAGE.PROTEIN_100}></Image>
      );
    } else if (item == 75)
      return (
        <Image
          style={styles.smallbucket}
          source={images.PROTEIN_IMAGE.PROTEIN_75}></Image>
      );
    else if (item == 50)
      return (
        <Image
          style={styles.smallbucket}
          source={images.PROTEIN_IMAGE.PROTEIN_50}></Image>
      );
    else if (item == 25)
      return (
        <Image
          style={styles.smallbucket}
          source={images.PROTEIN_IMAGE.PROTEIN_25}></Image>
      );
  };
  const rendeCarbsItem = item => {
    if (item == 100) {
      return (
        <Image
          style={styles.smallbucket}
          source={images.CARBS_IMAGE.CARBS_100}></Image>
      );
    } else if (item == 75)
      return (
        <Image
          style={styles.smallbucket}
          source={images.CARBS_IMAGE.CARBS_75}></Image>
      );
    else if (item == 50)
      return (
        <Image
          style={styles.smallbucket}
          source={images.CARBS_IMAGE.CARBS_50}></Image>
      );
    else if (item == 25)
      return (
        <Image
          style={styles.smallbucket}
          source={images.CARBS_IMAGE.CARBS_25}></Image>
      );
  };
  const rendeMajorCarbsItem = item => {
    if (item.item == 100) {
      return (
        <Image
          style={styles.bucketImg}
          source={images.CARBS_IMAGE.CARBS_100}></Image>
      );
    } else if (item.item == 75)
      return (
        <Image
          style={styles.bucketImg}
          source={images.CARBS_IMAGE.CARBS_75}></Image>
      );
    else if (item.item == 50)
      return (
        <Image
          style={styles.bucketImg}
          source={images.CARBS_IMAGE.CARBS_50}></Image>
      );
    else if (item.item == 25)
      return (
        <Image
          style={styles.bucketImg}
          source={images.CARBS_IMAGE.CARBS_25}></Image>
      );
  };
  const rendeMajorFatItem = item => {
    if (item.item == 100) {
      return (
        <Image
          style={styles.bucketImg}
          source={images.FAT_IMAGE.ORANGE_100}></Image>
      );
    } else if (item.item == 75)
      return (
        <Image
          style={styles.bucketImg}
          source={images.FAT_IMAGE.ORANGE_75}></Image>
      );
    else if (item.item == 50)
      return (
        <Image
          style={styles.bucketImg}
          source={images.FAT_IMAGE.ORANGE_50}></Image>
      );
    else if (item.item == 25)
      return (
        <Image
          style={styles.bucketImg}
          source={images.FAT_IMAGE.ORANGE_25}></Image>
      );
  };
  const rendeMajorProteinItem = item => {
    if (item.item == 100) {
      return (
        <Image
          style={styles.bucketImg}
          source={images.PROTEIN_IMAGE.PROTEIN_100}></Image>
      );
    } else if (item.item == 75)
      return (
        <Image
          style={styles.bucketImg}
          source={images.PROTEIN_IMAGE.PROTEIN_75}></Image>
      );
    else if (item.item == 50)
      return (
        <Image
          style={styles.bucketImg}
          source={images.PROTEIN_IMAGE.PROTEIN_50}></Image>
      );
    else if (item.item == 25)
      return (
        <Image
          style={styles.bucketImg}
          source={images.PROTEIN_IMAGE.PROTEIN_25}></Image>
      );
  };
  const renderMealView = () => {
    return (
      <FlatList
        horizontal
        extraData={isUpdating}
        showsHorizontalScrollIndicator={false}
        data={mealMainArray}
        renderItem={MealItem}></FlatList>
    );
  };
  const MealItem = item => {
    // console.log('MealItem.item=>', item.item);
    const {
      name,
      description,
      image,
      carbs,
      fat,
      protein,
      fiber,
      quantity,
      unit,
      calories,
      favorite,
      calories_percentage,
      measurement,
      id,
    } = item.item;
    return (
      <View style={styles.mealitemc}>
        <View style={styles.favmealsC}>
          <View style={styles.mealc}>
            <View style={globalStyles.flex_68}>
              <Text numberOfLines={1} style={styles.melaname}>
                {name}
              </Text>
              <Text numberOfLines={1} style={styles.mealcategory}>
                {quantity + ` ` + unit}
              </Text>
              {/* <SelectDropdown
                data={dummyContent.piece}
                onSelect={(selectedItem, index) => {
                  console.log(selectedItem);
                  //setFoodPieceCount(selectedItem);
                  updateServingsThroughPeiceQtyBasis(selectedItem);
                  //updateQty(selectedItem);
                }}
                // defaultButtonText={
                //   selectedFoodItem?.quantity + selectedFoodItem?.unit
                // }
                defaultButtonText={quantity + ` ` + unit}
                //defaultButtonText={foodPieceCount + servingUnit}
                buttonTextAfterSelection={(selectedItem, index) => {
                  return selectedItem;
                }}
                rowTextForSelection={(item, index) => {
                  return item;
                }}
                renderDropdownIcon={() => {
                  return (
                    <Image
                      style={{
                        height: 12,
                        width: 12,
                        resizeMode: 'contain',
                        //   transform: [{rotate: '270deg'}],
                      }}
                      source={images.SIGNUP.DOWN_ARROW}
                    />
                  );
                }}
                buttonStyle={styles.dropdownSmall4BtnStyle}
                buttonTextStyle={styles.dropdown4BtnTxtStyle}
                dropdownIconPosition={'right'}
                dropdownStyle={styles.dropdown4DropdownStyle}
                rowStyle={styles.dropdown4RowStyle}
                rowTextStyle={styles.dropdown4RowTxtStyle}
              /> */}

              <View style={globalStyles.flex_row}>
                <ImageBackground
                  source={{uri: image}}
                  borderRadius={10}
                  style={styles.mealimg}></ImageBackground>

                <View>
                  {fat.length > 0 && (
                    <View style={styles.mealinnerc}>
                      <View style={{flex: 0.35}}>
                        <Text
                          style={[
                            styles.forgot_pass_heading,
                            styles.whydesc,
                            styles.orange,
                            globalStyles.mt_0,
                          ]}>
                          {`Fats:`}
                        </Text>
                      </View>

                      <View
                        style={{
                          flex: 0.65,
                        }}>
                        <ScrollView
                          showsHorizontalScrollIndicator={false}
                          //style={{width: 10, backgroundColor: 'red'}}
                          contentContainerStyle={{alignItems: 'center'}}
                          horizontal>
                          {fat.map(item => rendeFatItem(item))}
                        </ScrollView>
                      </View>
                    </View>
                  )}
                  {carbs.length > 0 && (
                    <View style={styles.mealinnerc}>
                      <View style={{flex: 0.35}}>
                        <Text
                          style={[
                            styles.forgot_pass_heading,
                            styles.whydesc,
                            styles.red,
                            globalStyles.mt_0,
                          ]}>
                          {`Carbs:`}
                        </Text>
                      </View>
                      <View style={{flex: 0.65}}>
                        <ScrollView
                          showsHorizontalScrollIndicator={false}
                          horizontal
                          contentContainerStyle={{alignItems: 'center'}}>
                          {carbs.map(item => rendeCarbsItem(item))}
                        </ScrollView>
                      </View>
                    </View>
                  )}
                  {protein.length > 0 && (
                    <View style={styles.mealinnerc}>
                      <View style={{flex: 0.35}}>
                        <Text
                          style={[
                            styles.forgot_pass_heading,
                            styles.whydesc,
                            styles.green,
                            globalStyles.mt_0,
                          ]}>
                          {`Protein:`}
                        </Text>
                      </View>
                      <View style={{flex: 0.65}}>
                        <ScrollView
                          showsHorizontalScrollIndicator={false}
                          horizontal
                          contentContainerStyle={{alignItems: 'center'}}>
                          {protein.map(item => rendeProteinItem(item))}
                        </ScrollView>
                      </View>
                    </View>
                  )}
                </View>
              </View>
            </View>
            <View style={globalStyles.flex_32_aligncenter}>
              <View style={styles.progressbar}>
                <GradientCircularProgress
                  startColor={colors.primary}
                  middleColor={colors.secondary}
                  endColor={colors.primary}
                  size={47}
                  emptyColor={colors.black}
                  progress={calories_percentage}
                  strokeWidth={6}>
                  <Text style={styles.lbs}>{calories}</Text>
                </GradientCircularProgress>
                <Text
                  style={[
                    styles.bucketSize,
                    globalStyles.mt_0,
                    styles.headingtextBlack,
                  ]}>
                  {strings.calories}
                </Text>
              </View>
              {/* {MEAL_ID ? (
                <Pressable
                  style={styles.minusc}
                  onPress={() => [
                    setUpdating(!isUpdating),
                    onSetSelectedItemPress(item.item),
                    (tempItem = item.item),
                    setUpdating(!isUpdating),
                    (tempIndex = item.index),
                    (clickedIndex = item.index),
                    //onEditButtonClick(item.item, item.index),
                  ]}>
                  <Image
                    style={styles.heart}
                    source={images.APP.PENCIL}></Image>
                </Pressable>
              ) : (
                <Pressable onPress={() => onHeartPress(item)}>
                  <Image
                    style={styles.heart}
                    source={
                      favorite == 0 ? images.APP.HEART : images.APP.LIKED
                    }></Image>
                </Pressable>
              )} */}
              {/* {MEAL_ID && (
                <Pressable
                  style={styles.minusc}
                  onPress={() => [
                    setUpdating(!isUpdating),
                    onSetSelectedItemPress(item.item),
                    (tempItem = item.item),
                    (tempIndex = item.index),
                    (clickedIndex = item.index),
                    //onEditButtonClick(item.item, item.index),
                  ]}>
                  <Image
                    style={styles.heart}
                    source={images.APP.PENCIL}></Image>
                </Pressable>
              )} */}

              <Pressable
                style={styles.minusc}
                onPress={() => [
                  setUpdating(!isUpdating),
                  onSetSelectedItemPress(item?.item),
                  (tempItem = item?.item),
                  (temp_food_id_ = id),
                  (clickedIndex = item?.index),
                  //onEditButtonClick(item.item, item.index),
                ]}>
                <Image style={styles.heart} source={images.APP.PENCIL}></Image>
              </Pressable>

              {/* {item.index > 0 ? (
                <TouchableOpacity
                  onPress={() => onDeleteFoodPress(item)}
                  style={styles.minusc}>
                  <Image
                    style={styles.minusimage}
                    source={images.APP.TRASH}></Image>
                </TouchableOpacity>
              ) : (
                <TouchableOpacity
                  style={{height: 40, width: 40}}></TouchableOpacity>
              )} */}
              <Pressable onPress={() => onHeartPress(item)}>
                <Image
                  style={styles.hearts}
                  source={
                    favorite == 0 ? images.APP.HEART : images.APP.LIKED
                  }></Image>
              </Pressable>

              <TouchableOpacity
                onPress={() => onDeleteFoodPress(item)}
                style={styles.minusc}>
                <Image
                  style={styles.minusimage}
                  source={images.APP.TRASH}></Image>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </View>
    );
  };
  const CopyMealView = () => {
    return (
      <FlatList
        horizontal
        extraData={isUpdating}
        showsHorizontalScrollIndicator={false}
        data={mealMainArray}
        renderItem={CopyMealItem}></FlatList>
    );
  };
  const CopyMealItem = item => {
    console.log('MealItem.item=>', item.item);
    const {
      name,
      description,
      image,
      carbs,
      fat,
      protein,
      fiber,
      quantity,
      unit,
      calories,
      favorite,
      calories_percentage,
      measurement,
      id,
    } = item.item;
    return (
      <View style={styles.mealitemcopyMeal}>
        <View style={styles.favmealsC}>
          <View style={styles.mealc}>
            <View style={globalStyles.flex_68}>
              <Text numberOfLines={1} style={styles.melaname}>
                {name}
              </Text>
              <Text numberOfLines={1} style={styles.mealcategory}>
                {quantity + ` ` + unit}
              </Text>

              <View style={globalStyles.flex_row}>
                <ImageBackground
                  source={{uri: image}}
                  borderRadius={10}
                  style={styles.mealimgCopyMeal}></ImageBackground>

                <View>
                  {fat.length > 0 && (
                    <View style={styles.mealinnerc}>
                      <View style={{flex: 0.35}}>
                        <Text
                          style={[
                            styles.forgot_pass_heading,
                            styles.whydesc,
                            styles.orange,
                            globalStyles.mt_0,
                          ]}>
                          {`Fats:`}
                        </Text>
                      </View>

                      <View
                        style={{
                          flex: 0.65,
                        }}>
                        <ScrollView
                          showsHorizontalScrollIndicator={false}
                          //style={{width: 10, backgroundColor: 'red'}}
                          contentContainerStyle={{alignItems: 'center'}}
                          horizontal>
                          {fat.map(item => rendeFatItem(item))}
                        </ScrollView>
                      </View>
                    </View>
                  )}
                  {carbs.length > 0 && (
                    <View style={styles.mealinnerc}>
                      <View style={{flex: 0.35}}>
                        <Text
                          style={[
                            styles.forgot_pass_heading,
                            styles.whydesc,
                            styles.red,
                            globalStyles.mt_0,
                          ]}>
                          {`Carbs:`}
                        </Text>
                      </View>
                      <View style={{flex: 0.65}}>
                        <ScrollView
                          showsHorizontalScrollIndicator={false}
                          horizontal
                          contentContainerStyle={{alignItems: 'center'}}>
                          {carbs.map(item => rendeCarbsItem(item))}
                        </ScrollView>
                      </View>
                    </View>
                  )}
                  {protein.length > 0 && (
                    <View style={styles.mealinnerc}>
                      <View style={{flex: 0.35}}>
                        <Text
                          style={[
                            styles.forgot_pass_heading,
                            styles.whydesc,
                            styles.green,
                            globalStyles.mt_0,
                          ]}>
                          {`Protein:`}
                        </Text>
                      </View>
                      <View style={{flex: 0.65}}>
                        <ScrollView
                          showsHorizontalScrollIndicator={false}
                          horizontal
                          contentContainerStyle={{alignItems: 'center'}}>
                          {protein.map(item => rendeProteinItem(item))}
                        </ScrollView>
                      </View>
                    </View>
                  )}
                </View>
              </View>
            </View>
            <View style={globalStyles.flex_32_aligncenter}>
              <View style={styles.progressbar}>
                <GradientCircularProgress
                  startColor={colors.primary}
                  middleColor={colors.secondary}
                  endColor={colors.primary}
                  size={47}
                  emptyColor={colors.black}
                  progress={calories_percentage}
                  strokeWidth={6}>
                  <Text style={styles.lbs}>{calories}</Text>
                </GradientCircularProgress>
                <Text
                  style={[
                    styles.bucketSize,
                    globalStyles.mt_0,
                    styles.headingtextBlackCopyMeal,
                  ]}>
                  {strings.calories}
                </Text>
              </View>

              <Pressable
                style={styles.minusc}
                onPress={() => [
                  setUpdating(!isUpdating),
                  (temp_food_id_ = id),
                  onSetSelectedItemPress(item?.item),
                  (tempItem = item?.item),
                  (clickedIndex = item?.index),
                  //onEditButtonClick(item.item, item.index),
                ]}>
                <Image style={styles.heart} source={images.APP.PENCIL}></Image>
              </Pressable>

              <TouchableOpacity
                onPress={() =>
                  item.index > 0
                    ? onDeleteFoodPress(item)
                    : Utility.getInstance().inflateToast(
                        'You Cannot delete all foods In Copying Meal Phase.',
                      )
                }
                style={styles.minusc}>
                <Image
                  style={styles.minusimage}
                  source={images.APP.TRASH}></Image>
              </TouchableOpacity>

              {/* <TouchableOpacity
                onPress={() => onDeleteFoodPress(item)}
                style={styles.minusc}>
                <Image
                  style={styles.minusimage}
                  source={images.APP.TRASH}></Image>
              </TouchableOpacity> */}
            </View>
          </View>
        </View>
      </View>
    );
  };
  const CarbsBucketView = () => {
    return (
      <View
        style={{
          justifyContent: 'space-between',
          flexDirection: 'row',
          alignItems: 'flex-start',
          paddingHorizontal: 20,
          paddingVertical: 5,
        }}>
        <View style={{flex: 0.2}}>
          <Text
            style={[styles.forgot_pass_heading, styles.whydesc, styles.red]}>
            {`Carbs: `}
          </Text>
        </View>

        <View style={{flex: 0.8}}>
          <FlatList
            numColumns={6}
            //horizontal
            showsHorizontalScrollIndicator={false}
            data={carbsArray}
            renderItem={rendeMajorCarbsItem}></FlatList>
        </View>
      </View>
    );
  };
  const FatBucketView = () => {
    return (
      <View
        style={{
          justifyContent: 'space-between',
          flexDirection: 'row',
          alignItems: 'flex-start',
          paddingHorizontal: 20,
          paddingVertical: 5,
        }}>
        <View style={{flex: 0.2}}>
          <Text
            style={[styles.forgot_pass_heading, styles.whydesc, styles.orange]}>
            {`Fats:`}
          </Text>
        </View>

        <View style={{flex: 0.8}}>
          <FlatList
            showsHorizontalScrollIndicator={false}
            data={fatArray}
            numColumns={6}
            renderItem={rendeMajorFatItem}></FlatList>
        </View>
      </View>
    );
  };
  const ProteinBucketView = () => {
    return (
      <View
        style={{
          justifyContent: 'space-between',
          flexDirection: 'row',
          alignItems: 'flex-start',
          paddingHorizontal: 20,
          paddingVertical: 5,
        }}>
        <View style={{flex: 0.2}}>
          <Text
            style={[styles.forgot_pass_heading, styles.whydesc, styles.green]}>
            {`Protein:`}
          </Text>
        </View>

        <View style={{flex: 0.8}}>
          <FlatList
            numColumns={6}
            showsHorizontalScrollIndicator={false}
            data={proteinArray}
            renderItem={rendeMajorProteinItem}></FlatList>
        </View>
      </View>
    );
  };
  const Modal = () => {
    return (
      <DialogView
        onTouchOutside={() => console.log('onTouchOutside')}
        willInflate={willInflate}
        onBackPress={() => setWillInflate(false)}
        children={ModalContent()}></DialogView>
    );
  };
  const ModalContent = () => {
    return (
      <View>
        <View
          style={{
            marginTop: 1,
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <Text
            style={{
              textAlign: 'center',
              fontFamily: 'Poppins-SemiBold',
              color: colors.black,
              fontSize: 25,
            }}>
            {` Meal 
Submitted`}
          </Text>

          <Text
            style={{
              textAlign: 'center',
              fontFamily: 'Poppins-Light',
              marginTop: 20,
              color: colors.black,
            }}>
            {alreadyFavorite
              ? 'Your Meal has been submitted. This meal is already in your favorite meals.'
              : 'Your Meal has been submitted. Would you like to favorite this meal so you can add it faster in the future?'}
          </Text>

          {alreadyFavorite ? (
            <>
              <TouchableOpacity
                onPress={() => [
                  setWillInflate(false),
                  navigation.navigate('Home'),
                  clearFavMealGlobalVariableDetails(),
                ]}
                style={[
                  globalStyles.button_secondary,
                  globalStyles.center,
                  globalStyles.mt_30,
                ]}>
                <Text style={globalStyles.btn_heading_black}>{'CONTINUE'}</Text>
              </TouchableOpacity>
            </>
          ) : (
            <>
              <TouchableOpacity
                onPress={() => [setWillInflate(false), addMealToFavCall()]}
                style={[
                  globalStyles.button_secondary,
                  globalStyles.center,
                  globalStyles.mt_30,
                ]}>
                <Text style={globalStyles.btn_heading_black}>
                  {'ADD TO FAVORITES'}
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => [
                  setWillInflate(false),
                  navigation.navigate('Home'),
                  clearFavMealGlobalVariableDetails(),
                ]}
                style={[
                  globalStyles.button_secondarywithoutBlackBack,
                  globalStyles.center,
                  globalStyles.mt_30,
                ]}>
                <Text style={globalStyles.btn_heading_black}>
                  {'SKIP FOR NOW'}
                </Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </View>
    );
  };
  const DateView = () => {
    return (
      <FlatList
        horizontal
        style={{marginTop: 15}}
        renderItem={renderDates}
        /// extraData={dateArray}
        ref={scrollRef}
        onScrollToIndexFailed={scrollToIndexFailed}
        keyExtractor={item => item.toString() + 2.9}
        contentContainerStyle={{paddingHorizontal: 20}}
        showsHorizontalScrollIndicator={false}
        data={dateArray}></FlatList>
    );
  };

  const renderDates = item => {
    const {show_date, date} = item.item;
    return (
      <Pressable
        onPress={() => [
          saveSelectedDate(date),
          setDate(date),

          (dateSelected = date),
        ]}
        style={[
          styles.dateView_,
          {
            borderWidth: dateValue == date ? 2 : 0.3,
          },
        ]}>
        <Text
          style={[
            styles.headingT,
            {color: dateValue == date ? colors.white : colors.gray},
          ]}>
          {show_date}
        </Text>
      </Pressable>
    );
  };
  const removerMealId = async () => {
    dispatch(clearFoodId());
    await Utility.getInstance().removeStoreData('MEAL_ID');
  };
  const DefautView = () => {
    return (
      <View style={[styles.flex, {backgroundColor: colors.primary}]}>
        <Header
          onBackPress={() => {
            draftFoodsData ? discardAlert() : backPress();
          }}
          profileClick={() => removerMealId()}
        />
        <ScrollView>
          {!MEAL_ID && DateView()}
          {HeaderInfo()}
          {renderMealView()}
          {MEAL_ID && (
            <Pressable
              onPress={() => setWillInflateCopyMeal(true)}
              style={{flexDirection: 'row', padding: 10, alignItems: 'center'}}>
              <Image
                style={{height: 20, width: 20, resizeMode: 'contain'}}
                source={images.APP.COPY}></Image>
              <Text
                numberOfLines={1}
                style={[
                  styles.melaname,
                  globalStyles.mr_left,
                  globalStyles.white,
                  globalStyles.font14,
                ]}>
                COPY MEAL
              </Text>
            </Pressable>
          )}
          <Text
            style={[
              globalStyles.textAlignCenter,
              styles.white,
              globalStyles.mt_20,
              globalStyles.font17,
            ]}>
            {strings.totalBuckets}
          </Text>
          <View style={globalStyles.padding_20_hor}>
            {carbsArray.length > 0 && CarbsBucketView()}
            {fatArray.length > 0 && FatBucketView()}
            {proteinArray.length > 0 && ProteinBucketView()}
          </View>
        </ScrollView>
        {MEAL_ID ? (
          <View
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              paddingHorizontal: 20,
              backgroundColor: 'transparent',
              height: 80,
              width: '60%',
              flexDirection: 'row',
              alignSelf: 'flex-end',
              alignContent: 'center',
            }}>
            <Text
              onPress={() => [onDeleteMealPress()]}
              style={[globalStyles.btn_heading, {marginRight: 50}]}>
              DELETE
            </Text>
            {!Loading && (
              <Text
                onPress={() => [onDonePress()]}
                style={[globalStyles.btn_heading]}>
                {'UPDATE'}
              </Text>
            )}
          </View>
        ) : (
          <View
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              paddingHorizontal: 20,
              backgroundColor: 'transparent',
              height: 80,
              width: 100,
              flexDirection: 'row',
              alignSelf: 'flex-end',
              alignContent: 'center',
            }}>
            {!Loading && (
              <Text
                onPress={() => [onDonePress()]}
                style={[globalStyles.btn_heading]}>
                {'DONE'}
              </Text>
            )}
          </View>
        )}
      </View>
    );
  };

  return (
    <>
      {DefautView()}
      {Modal()}
      {EditFoodModal()}
      {CopyMealModal()}
      <Loader isLoading={isLoading || isLoadingFav || Loading} />
    </>
  );
};
export default MealView;
