import React, {useState, useEffect, useRef} from 'react';
import {
  View,
  Text,
  ImageBackground,
  TouchableOpacity,
  Image,
  ScrollView,
  FlatList,
  Pressable,
} from 'react-native';
import {logout} from '../../redux/action/LoginAction';
import {useNavigation} from '@react-navigation/native';
import images from '../../assets/images/index';
import Header from '../../component/headerWithBackControl';
import ImagePicker from 'react-native-image-crop-picker';
import styles from '../Profile/style';
import {useDispatch, useSelector} from 'react-redux';
import globalStyles from '../../assets/globalStyles/index.js';
import strings from '../../constants/strings';
import colors from '../../constants/colorCodes';
import Utility from '../../utility/Utility';
import Loader from '../../component/loader';
import {
  userProfileInfoRequest,
  uploadUserImageRequest,
} from '../../redux/action/UserProfileInfo';
import ApiConstant from '../../constants/api';
import {loginSuccess, loginRequest} from '../../redux/action/LoginAction';
import {favMealListRequest} from '../../redux/action/MealAction';
import ImagePickerBottomSheet from '../../component/imagePickerBottomSheet';
var userId = null;
const Profile = () => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const refRBSheet = useRef();
  const userData = useSelector(state => state.other.loginReducer.userData);
  const userInformationReducer = useSelector(
    state => state.other.userProfileInfoReducer.userData,
  );
  const isLoading = useSelector(
    state => state.other.userProfileInfoReducer.showLoader,
  );
  const [isProfile, setProfileSaved] = useState(false);
  const [isLoggedIn, setLoggedIn] = useState(false);

  const [favMeals, setfavMeals] = useState([]);

  const [clientCode, setClientCode] = useState('');
  const [location, setLocation] = useState('');
  const [userImage, setUserImage] = useState('');

  useEffect(() => {
    if (userData) {
      userId = userData.id;
    }
    getProfileInformation();
    getFavoriteList();
  }, []);

  const onSU = reoslve => {};
  const onFA = () => {};

  const getFavoriteList = () => {
    let payload = {
      uid: userId,
    };
    dispatch(favMealListRequest(payload, onSSS, onFFF));
  };
  const onSSS = resolve => {
    setfavMeals(resolve.data);
  };
  const onFFF = reject => {};

  const getProfileInformation = () => {
    dispatch(userProfileInfoRequest(userId, onSucc, onFail));
  };
  const onSucc = resolve => {
    setUserImage(resolve.data.image);

    let client_code = resolve.data.client_code;
    if (client_code) {
      setLoggedIn(true);
      setClientCode(client_code);
    }
    if (resolve.data.location_details) {
      let location = JSON.parse(resolve.data.location_details);
      if (location) setLocation(location?.formattedAddress);
    } else {
      getLoctionFromLocalStorage();
    }
  };
  const getLoctionFromLocalStorage = async () => {
    let locationData = await Utility.getInstance().getStoreData(
      strings.location_data,
    );
    if (locationData) {
      const data = JSON.parse(locationData);
      setLocation(data?.formattedAddress);
    }
  };
  const onFail = reject => {
    Utility.getInstance().inflateToast(reject);
  };
  const backPress = () => {
    navigation.navigate('Home');
  };
  const onSettingPress = () => {
    navigation.navigate('Setting');
  };
  const onUpdateProfilePress = () => {
    refRBSheet.current.open();
  };
  const pickORCapture = TYPE => {
    refRBSheet.current.open();
    if (TYPE == 'CAMERA') {
      ImagePicker.openCamera({
        width: 400,
        height: 300,
        mediaType: 'photo',
        cropping: true,
        compressImageQuality: 0.8,
        compressImageMaxWidth: 400,
        compressImageMaxHeight: 300,
      })
        .then(image => {
          refRBSheet.current.close();
          generateImage(image);
        })
        .catch(e => {
          Utility.getInstance().inflateToast(JSON.stringify(e.message));
        });
    } else if (TYPE == 'GALLERY') {
      ImagePicker.openPicker({
        width: 400,
        height: 300,
        mediaType: 'photo',
        cropping: true,
        compressImageQuality: 0.8,
        compressImageMaxWidth: 400,
        compressImageMaxHeight: 300,
      })
        .then(image => {
          generateImage(image);
          refRBSheet.current.close();
        })
        .catch(e => {});
    }
  };
  const generateImage = async data => {
    const localUri = data.path;
    const filename = localUri.split('/').pop();
    let fileType = data.mime;
    const File = {
      uri: localUri,
      name: filename,
      type: fileType,
    };
    setUserImage(localUri);
    setTimeout(() => {
      uploadUserImage(File);
    }, 100);
  };

  const uploadUserImage = async imageFile => {
    setProfileSaved(true);
    var formdata = new FormData();
    formdata.append('uid', userId);
    formdata.append('image', imageFile);
    var requestOptions = {
      method: 'POST',
      body: formdata,
      redirect: 'follow',
    };
    await fetch(
      ApiConstant.BASE_URL + ApiConstant.UPLOAD_USER_IMAGE,
      requestOptions,
    )
      .then(response => response.text())
      .then(result => onSUploadImage(JSON.parse(result)))
      .catch(error => onFUploadImage(error));
  };

  const onSUploadImage = resolve => {
    setProfileSaved(false);
    if (resolve) {
      let updatedImageUri = resolve.data.image;
      if (userData) {
        let payload = {
          data: {
            ...userData,
            image: updatedImageUri,
          },
        };
        dispatch(loginSuccess(payload, onSU, onFA));
      }
    }
  };
  const onFUploadImage = reject => {
    setProfileSaved(false);
  };

  const GoalView = () => {
    return (
      <Pressable
        onPress={() => navigation.navigate('MyGoal')}
        style={styles.goalc}>
        <View style={[styles.addView_green]}>
          <Text style={globalStyles.btn_heading_black}>MY GOALS</Text>
        </View>
      </Pressable>
    );
  };
  const FavMealView = () => {
    return (
      <FlatList
        style={{margin: 10}}
        horizontal
        showsHorizontalScrollIndicator={false}
        data={favMeals}
        renderItem={renderFavMealItem}></FlatList>
    );
  };

  const onDetailsPress = async item => {
    global.is_fav_meal = true;
    const {id, food_id, quantity, meal_name, fav_id} = item;

    global.fav_id = fav_id;
    Global = meal_name;
    let foodId = food_id.toString();
    let mealId = id;
    console.log('onDetailsPress======', item);
    await Utility.getInstance()
      .setStoreData('MEAL_ID', id)
      .then(() => {
        navigation.navigate('MealView', {
          foodId,
          qty: quantity.toString(),
          mealId,
        });
      });
  };
  const renderFavMealItem = item => {
    const {names, image, description, id, quantity, food_id} = item.item;
    let foodId = food_id;
    let qty = quantity;

    return (
      <Pressable
        onPress={() => [onDetailsPress(item?.item)]}
        style={styles.favmealsC}>
        <Text numberOfLines={1} style={styles.melaname}>
          {names}
        </Text>
        <Text numberOfLines={1} style={styles.mealcategory}>
          {description}
        </Text>
        <ImageBackground
          source={image ? {uri: image} : images.PROFILE.CHICKEN}
          borderRadius={10}
          style={styles.mealimg}></ImageBackground>
      </Pressable>
    );
  };
  const DefautView = () => {
    return (
      <View style={[styles.flex, {backgroundColor: colors.primary}]}>
        <ImagePickerBottomSheet
          openCamera={() => pickORCapture('CAMERA')}
          openFiles={() => pickORCapture('GALLERY')}
          reference={refRBSheet}
        />
        <Header onBackPress={() => backPress()} />
        <Loader isLoading={isLoading || isProfile} />

        <ScrollView
          contentContainerStyle={{paddingVertical: 20}}
          showsVerticalScrollIndicator={false}>
          <View style={[globalStyles.center, globalStyles.padding_40]}>
            <Text style={[styles.why_heading, styles.font30]}>
              {strings.profile}
            </Text>
            <View style={styles.profilec}>
              <Image
                style={styles.userlogoSizeBig}
                source={{uri: userImage}}></Image>
              <View
                style={{
                  marginLeft: 20,
                  marginVertical: 10,
                  justifyContent: 'flex-end',
                }}>
                <Text style={[styles.why_heading, styles.font30, styles.white]}>
                  {userInformationReducer && userInformationReducer.name}
                </Text>
                <Text
                  onPress={onUpdateProfilePress}
                  style={[
                    styles.forgot_pass_heading,
                    styles.green,
                    globalStyles.underline_green,
                    {marginTop: -5},
                  ]}>
                  {strings.updateprofile}
                </Text>
              </View>
            </View>
            <Text style={[styles.forgot_pass_heading, styles.whydesc]}>
              {strings.plancode}
            </Text>
            {isLoggedIn ? (
              <Text style={[styles.forgot_pass_heading, styles.green]}>
                {clientCode}
              </Text>
            ) : (
              <>
                <Text
                  style={[
                    styles.forgot_pass_heading,
                    styles.whydesc,
                    styles.green,
                  ]}>
                  {strings.noplan}
                </Text>
                <Text
                  onPress={() => navigation.navigate('Chat', 0)}
                  style={[
                    styles.forgot_pass_heading,
                    styles.green,
                    globalStyles.underline_green,
                  ]}>
                  {strings.signupnow}
                </Text>
              </>
            )}
            <Text
              style={[
                styles.whydesc,
                styles.green,
                globalStyles.textAlignStart,
                {marginBottom: -20},
              ]}>
              {strings.profiles}
            </Text>
          </View>
          <Pressable
            onPress={() => navigation.navigate('Setting', 0)}
            style={styles.profileclist}>
            <Text
              style={[
                styles.whydesc,
                styles.white,
                globalStyles.mt_0,
                globalStyles.font17,
              ]}>
              {strings.age}
            </Text>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <Text
                style={[
                  styles.whydesc,
                  styles.white,
                  globalStyles.mt_0,
                  globalStyles.mr_10,
                ]}>
                {userInformationReducer && userInformationReducer.age}
              </Text>
              <Image
                style={styles.nextimg}
                source={images.PROFILE.NEXT}></Image>
            </View>
          </Pressable>
          <Pressable
            onPress={() => navigation.navigate('Setting', 0)}
            style={styles.profileclist}>
            <Text
              style={[
                styles.whydesc,
                styles.white,
                globalStyles.mt_0,
                globalStyles.font17,
              ]}>
              {strings.gender}
            </Text>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <Text
                style={[
                  styles.whydesc,
                  styles.white,
                  globalStyles.mt_0,
                  globalStyles.mr_10,
                ]}>
                {userInformationReducer && userInformationReducer.gender}
              </Text>
              <Image
                style={styles.nextimg}
                source={images.PROFILE.NEXT}></Image>
            </View>
          </Pressable>
          <Pressable
            onPress={() => navigation.navigate('Setting', 0)}
            style={[styles.profileclist, {flex: 1}]}>
            <Text
              style={[
                styles.whydesc,
                styles.white,
                globalStyles.mt_0,
                globalStyles.font17,
                {flex: 0.4},
              ]}>
              {'Additional Info'}
            </Text>
            <View
              style={{flexDirection: 'row', alignItems: 'center', flex: 0.6}}>
              <Text
                numberOfLines={1}
                style={[
                  styles.whydesc,
                  styles.white,
                  globalStyles.mt_0,
                  globalStyles.mr_10,
                ]}>
                {location}
              </Text>
              <Image
                style={styles.nextimg}
                source={images.PROFILE.NEXT}></Image>
            </View>
          </Pressable>
          <GoalView />
          <View style={globalStyles.padding_20_hor}>
            {favMeals.length > 0 && (
              <Text
                style={[
                  styles.whydesc,
                  styles.green,
                  globalStyles.textAlignStart,
                ]}>
                {strings.favmeals}
              </Text>
            )}
          </View>
          <FavMealView />
          <Text
            onPress={onSettingPress}
            style={[
              styles.font30,
              globalStyles.textAlignCenter,
              styles.green,
              globalStyles.mt_20,
            ]}>
            {strings.mystats}
          </Text>
        </ScrollView>
      </View>
    );
  };

  return DefautView();
};
export default Profile;
