import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  ImageBackground,
  TouchableOpacity,
  Image,
  ScrollView,
  FlatList,
  Pressable,
  Switch,
  TextInput,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {useDispatch, useSelector} from 'react-redux';
import styles from '../MyGoal/style';
import images from '../../assets/images';
import Utility from '../../utility/Utility';
import Header from '../../component/headerWithBackControl';
import globalStyles from '../../assets/globalStyles/index';
import strings from '../../constants/strings';
import Loader from '../../component/loader';
import colors from '../../constants/colorCodes';
import {userProfileInfoRequest} from '../../redux/action/UserProfileInfo';
import {updateUserInformationRequest} from '../../redux/action/UserProfileInfo';
import {
  CircularProgress,
  GradientCircularProgress,
} from 'react-native-circular-gradient-progress';
var userId = null;
var currentWeight = 0;
const MyGoal = () => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const userData = useSelector(state => state.other.loginReducer.userData);
  const userInformationReducer = useSelector(
    state => state.other.userProfileInfoReducer.userData,
  );
  const isLoading = useSelector(
    state => state.other.userProfileInfoReducer.showLoader,
  );

  const [description, setDescription] = useState('');
  const onEditGoalPress = () =>
    navigation.navigate('MonthGoal', {
      FROM: 'MyGoal',
      CURRENT_WEIGHT: currentWeight + `lbs`,
    });
  useEffect(() => {
    if (userData) {
      userId = userData.id;
    }
    const focus = navigation.addListener('focus', () => {
      getUserProfileInformation();
    });
    return () => {
      focus;
    };
  }, []);

  const getUserProfileInformation = () => {
    dispatch(userProfileInfoRequest(userId, onSucc, onFail));
  };
  const onSucc = resolve => {
    console.log('resolve', resolve);
    const {data} = resolve;
    setDescription(data?.description);
    currentWeight = data.c_weight;
  };
  const onFail = reject => {
    Utility.getInstance().inflateToast(reject);
  };

  const backPress = () => {
    navigation.goBack();
  };

  const GoalView = () => {
    return (
      <Pressable
        onPress={onEditGoalPress}
        style={[styles.addView_green, {alignSelf: 'flex-end'}]}>
        <Text
          style={[
            styles.headingtextBlack,
            {fontSize: 15, fontFamily: 'Poppins-Medium'},
          ]}>
          EDIT MY GOALS
        </Text>
      </Pressable>
    );
  };
  const BottomTabMenu = () => {
    return (
      <View style={globalStyles.bottom_tab_c}>
        <TouchableOpacity
          onPress={() => navigation.navigate('MyGoal')}
          style={globalStyles.bottom_tab_item_c}>
          <Image
            source={images.APP.GOAL}
            style={[
              globalStyles.bottom_tab_item_img,
              {tintColor: colors.secondary},
            ]}
          />
          <Text style={[globalStyles.bottom_tab_text, {color: colors.white}]}>
            Goals
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => navigation.navigate('AddMeal')}
          style={globalStyles.bottom_tab_item_c}>
          <Text
            style={[
              globalStyles.bottom_tab_text,
              {marginTop: -10, color: colors.white},
            ]}>
            Add Meal
          </Text>
          <View style={globalStyles.bottom_tab_addmeal_c}>
            <Image
              source={images.SIGNUP.PLUS}
              style={[
                globalStyles.bottom_tab_item_img_plus,
                {tintColor: colors.secondary},
              ]}
            />
          </View>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => navigation.navigate('ProgressReport')}
          style={globalStyles.bottom_tab_item_c}>
          <Image
            source={images.APP.PROGRESS}
            style={[
              globalStyles.bottom_tab_item_img,
              {tintColor: colors.white},
            ]}
          />
          <Text style={[globalStyles.bottom_tab_text, {color: colors.white}]}>
            Progress
          </Text>
        </TouchableOpacity>
      </View>
    );
  };
  const onStepsCompletedPress = () => {
    if (description) {
      let payloadToSend = {
        uid: userId,
        description: description,
      };
      dispatch(updateUserInformationRequest(payloadToSend, onS, onF));
    } else {
      Utility.getInstance().inflateToast('Please enter description.');
    }
  };
  const onS = resolve => {
    console.log('onStepsCompletedPress==', resolve);
    setTimeout(() => {
      Utility.getInstance().inflateToast('Your description saved sucessfully');
    }, 100);
  };
  const onF = reject => {};

  const step3 = () => {
    return (
      <>
        <View
          style={[
            styles.flex_9,
            globalStyles.center,
            globalStyles.padding_40,
            globalStyles.mt_30,
          ]}>
          <Text style={[styles.why_heading, globalStyles.regular]}>
            {strings.why}
          </Text>
          <Text style={[styles.forgot_pass_heading, styles.whydesc]}>
            {strings.whydesc}
          </Text>

          <TextInput
            onChangeText={text => setDescription(text)}
            value={description}
            textAlignVertical="top"
            multiline={true}
            style={styles.biginput}
          />

          <TouchableOpacity
            onPress={onStepsCompletedPress}
            style={[
              globalStyles.button_secondary,
              globalStyles.center,
              globalStyles.button,
              globalStyles.mt_30,
            ]}>
            <Text style={globalStyles.btn_heading_black}>{'Save'}</Text>
          </TouchableOpacity>
        </View>
      </>
    );
  };
  const DefautView = () => {
    return (
      <>
        <View style={[styles.flex, {backgroundColor: colors.primary}]}>
          <Header onBackPress={() => backPress()} />
          <Loader isLoading={isLoading} />
          <ScrollView contentContainerStyle={{paddingVertical: 0}}>
            <View style={[globalStyles.padding_40]}>
              <Text style={[styles.why_heading, styles.font30, styles.white]}>
                {strings.mygoals}
              </Text>
              {!userInformationReducer?.client_code && <GoalView />}
            </View>
            <View style={styles.progressgoalc}>
              <View style={styles.progressgoalchildc}>
                <View style={styles.progressbar}>
                  <GradientCircularProgress
                    startColor={colors.primary}
                    middleColor={colors.secondary}
                    endColor={colors.primary}
                    size={85}
                    emptyColor={colors.black}
                    progress={70}
                    strokeWidth={6}>
                    <Text style={styles.lbs}>
                      {userInformationReducer &&
                        userInformationReducer.c_weight + `\nlbs`}
                    </Text>
                  </GradientCircularProgress>
                  <Text style={[styles.bucketSize, globalStyles.mt_10]}>
                    {strings.currenweight}
                  </Text>
                </View>
              </View>
              <View style={styles.progressgoalchildc}>
                <View style={styles.progressbar}>
                  <GradientCircularProgress
                    startColor={colors.primary}
                    middleColor={colors.secondary}
                    endColor={colors.primary}
                    size={85}
                    emptyColor={colors.black}
                    progress={70}
                    strokeWidth={6}>
                    <Text style={styles.lbs}>
                      {userInformationReducer &&
                        userInformationReducer.g_weight + `\nlbs`}
                    </Text>
                  </GradientCircularProgress>
                  <Text style={[styles.bucketSize, globalStyles.mt_10]}>
                    {strings.goalweights}
                  </Text>
                </View>
              </View>
            </View>

            {step3()}
          </ScrollView>
        </View>
        <BottomTabMenu />
      </>
    );
  };

  return DefautView();
};
export default MyGoal;
