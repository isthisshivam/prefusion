import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  ImageBackground,
  TouchableOpacity,
  Image,
  ScrollView,
  FlatList,
  TextInput,
  Pressable,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';

import styles from '../ApprovedFoods/style';
import Loader from '../../component/loader';
import Header from '../../component/headerWithBackControl';
import globalStyles from '../../assets/globalStyles/index';
import strings from '../../constants/strings';
import colors from '../../constants/colorCodes';
import {useDispatch, useSelector} from 'react-redux';
import {getApprovedFoodsRequest} from '../../redux/action/ApprovedFoodAction';
import ScrollableTabView, {
  DefaultTabBar,
  ScrollableTabBar,
} from 'react-native-scrollable-tab-view';

var userId = null;
const ApprovedFoods = () => {
  const navigation = useNavigation();
  const [value, setValue] = useState(0);
  const [dataArray, setDataArray] = useState([
    {
      name: 'Protein',
      data: [],
    },
    {
      name: 'Carbohydrates',
      data: [],
    },
    {
      name: 'Fats',
      data: [],
    },
  ]);
  const dispatch = useDispatch();
  const userData = useSelector(state => state.other.loginReducer.userData);
  const isLoading = useSelector(
    state => state.other.approvedFoodReducer.showLoader,
  );
  const [isCarbs, setCarbs] = useState(false);
  const [isFat, setFat] = useState(false);
  const [isProtein, setProtein] = useState(true);
  const [proteinArray, setProteinArray] = useState([]);
  const [fatArray, setFatArray] = useState([]);
  const [carbsArray, setCarbsArray] = useState([]);

  if (userData) {
    userId = userData.id;
  }
  useEffect(() => {
    getApprovedFoods();
  }, []);
  const getApprovedFoods = () => {
    let payload = {};
    dispatch(getApprovedFoodsRequest(payload, onS, onF));
  };

  const onS = resolve => {
    const {data} = resolve;
    setProteinArray(data.protein);
    setCarbsArray(data.carbs);
    setFatArray(data.fat);
  };

  const onF = reject => {};
  const backPress = () => {
    navigation.goBack();
  };
  const renderRow = item => {
    const {image, name, quantity, unit, amount} = item.item;
    return (
      <Pressable
        style={{
          height: 120,
          backgroundColor: colors.offwhite,
          marginTop: 10,
          paddingHorizontal: 20,
          borderBottomColor: 'gray',
          borderBottomWidth: 1,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
        <View style={[styles.myfavlistcontainerchild, {flex: 0.7}]}>
          <Image style={styles.image} source={{uri: image}}></Image>
          <Text style={[styles.ml_15, styles.black, {marginRight: '30%'}]}>
            {name}
          </Text>
        </View>
        <View style={{flex: 0.3}}>
          <Text style={[styles.ml_15, styles.black, {textAlign: 'auto'}]}>
            {amount}
          </Text>
        </View>
      </Pressable>
    );
  };
  const FoodItemListFat = data => {
    return (
      <FlatList
        data={data}
        style={{marginTop: 10}}
        showsVerticalScrollIndicator={false}
        renderItem={renderRow}></FlatList>
    );
  };
  const FoodItemListProtein = data => {
    return (
      <FlatList
        data={data}
        style={{marginTop: 10}}
        showsVerticalScrollIndicator={false}
        renderItem={renderRow}></FlatList>
    );
  };
  const FoodItemListCarbs = data => {
    return (
      <FlatList
        data={data}
        style={{marginTop: 10}}
        showsVerticalScrollIndicator={false}
        renderItem={renderRow}></FlatList>
    );
  };

  const DefautView = () => {
    return (
      <View style={[{backgroundColor: colors.primary}]}>
        <Header onBackPress={() => backPress()} />

        <View style={[globalStyles.center, globalStyles.padding_40]}>
          <Text style={[styles.why_heading, styles.font30]}>
            {strings.approvedfoods}
          </Text>
          <Text
            style={[
              styles.forgot_pass_heading,
              styles.whydesc,
              globalStyles.textAlignStart,
              styles.white,
            ]}>
            {strings.item}
          </Text>
        </View>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{
            padding: 0,
            alignItems: 'center',
            justifyContent: 'space-between',
            width: '100%',
            height: 100,
          }}
          style={{
            height: 100,
            backgroundColor: colors.primary,
            // flex: 1,
            width: '100%',
          }}>
          <Pressable
            onPress={() => [setCarbs(false), setFat(false), setProtein(true)]}
            style={{
              justifyContent: 'center',
              alignItems: 'center',
              borderBottomColor: isProtein ? colors.secondary : colors.primary,
              borderBottomWidth: 5,
              height: 38,
              //width: 120,
              flex: 1,
            }}>
            <Text
              style={{
                fontSize: isProtein ? 16 : 14,
                fontFamily: isProtein ? 'Poppins-Medium' : 'Poppins-Light',
                color: colors.secondary,
              }}>
              Protein
            </Text>
          </Pressable>
          <Pressable
            onPress={() => [setCarbs(true), setFat(false), setProtein(false)]}
            style={{
              justifyContent: 'center',
              alignItems: 'center',
              borderBottomColor: isCarbs ? colors.red : colors.primary,
              borderBottomWidth: 5,
              height: 38,
              // fontSize: isCarbs ? 16 : 14,
              // width: 80,
              flex: 1,
            }}>
            <Text
              style={{
                fontFamily: isCarbs ? 'Poppins-Medium' : 'Poppins-Light',
                color: isCarbs ? colors.red : colors.gray,
              }}>
              Carbohydrates
            </Text>
          </Pressable>
          <Pressable
            onPress={() => [setCarbs(false), setFat(true), setProtein(false)]}
            style={{
              justifyContent: 'center',
              alignItems: 'center',
              borderBottomColor: isFat ? colors.orange : colors.primary,
              borderBottomWidth: 5,
              height: 38,
              // fontSize: isFat ? 16 : 14,
              // width: 80,
              flex: 1,
            }}>
            <Text
              style={{
                fontFamily: isFat ? 'Poppins-Medium' : 'Poppins-Light',
                color: isFat ? colors.orange : colors.gray,
              }}>
              Fat
            </Text>
          </Pressable>
        </ScrollView>

        {isProtein && FoodItemListProtein(proteinArray)}
        {isCarbs && FoodItemListCarbs(carbsArray)}
        {isFat && FoodItemListFat(fatArray)}

        <Loader isLoading={isLoading} />
      </View>
    );
  };

  return <>{DefautView()}</>;
};
export default ApprovedFoods;
