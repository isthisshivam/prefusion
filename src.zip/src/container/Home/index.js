import React, {
  useState,
  useEffect,
  useRef,
  useLayoutEffect,
  useMemo,
} from 'react';
import {
  View,
  Text,
  ImageBackground,
  TouchableOpacity,
  Image,
  ScrollView,
  FlatList,
  Pressable,
  StatusBar,
  BackHandler,
  Platform,
  AppState,
} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import {useNavigation} from '@react-navigation/native';
import images from '../../assets/images/index';
import styles from '../Home/style';
import globalStyles from '../../assets/globalStyles/index.js';
import strings from '../../constants/strings';
import moment from 'moment';

import colors from '../../constants/colorCodes';
import Utility from '../../utility/Utility';
import Loader from '../../component/loader';
import {updateUserInformationRequest} from '../../redux/action/UserProfileInfo';
import api from '../../constants/api';
import Tooltip from 'react-native-walkthrough-tooltip';

import dummyContent from '../../constants/dummyContent';
import {weekelyDataRequest} from '../../redux/action/WeekelyDataAction';
import {
  CircularProgress,
  GradientCircularProgress,
} from 'react-native-circular-gradient-progress';
import RNPermissions, {PERMISSIONS, RESULTS} from 'react-native-permissions';

var userId = null;
var today = new Date();

const Home = () => {
  const navigation = useNavigation();
  const toolTipRef = useRef();
  const flatlistRef = useRef();
  const [showTip, setTip] = useState(false);
  const scrollRef = useRef();
  const dispatch = useDispatch();
  const [imageUri, setImageUri] = useState(null);
  const [isUpdating, setUpdating] = useState(false);
  const userData = useSelector(state => state.other.loginReducer.userData);
  const userWeeklyInstance = useSelector(
    state => state.other.weekelyDataReducer.userData,
  );
  const userWeeklyInstanceIsLoading = useSelector(
    state => state.other.weekelyDataReducer.showLoader,
  );
  const [isLoading, setLoading] = useState(false);
  const [isPrefusionClient, setClientStatus] = useState(false);
  const [dateValue, setDate] = useState('');
  const [carbsArray, setCarbsArray] = useState([]);
  const [fatArray, setFatArray] = useState([]);
  const [veggiesArray, setVeggArray] = useState([]);
  const [waterArray, setWaterArray] = useState([]);
  const [dateList, setDateList] = useState([]);
  const [proteinArray, setProteinArray] = useState([]);
  const [tooltipData, setToolTipData] = useState([]);

  useEffect(() => {
    const dateSet = async () => {
      let date_ = await Utility.getInstance().getSelectedDate();
      if (date_) {
        setDate(date_);
        getUserInstance(date_);
      } else {
        const date = await Utility.getInstance().getCurrentDateOnlyUser();
        setDate(date);
        getUserInstance(date);
      }
    };
    const appStateListener = AppState.addEventListener(
      'change',
      nextAppState => {
        console.log('appStateListener', nextAppState);
        if (nextAppState === 'active') dateSet();
        else if (nextAppState === 'background') clearDateImmediate();
      },
    );
    return () => {
      appStateListener?.remove();
    };
  }, []);

  useEffect(() => {
    const dateSet = async () => {
      let date_ = await Utility.getInstance().getSelectedDate();
      if (date_) {
        setDate(date_);
        getUserInstance(date_);
      } else {
        const date = await Utility.getInstance().getCurrentDateOnlyUser();
        setDate(date);
        getUserInstance(date);
      }
    };
    const unsubscribe = navigation.addListener('focus', () => {
      dateSet();
    });
    return () => {
      unsubscribe;
    };
  }, []);

  const clearDateImmediate = async () => {
    await Utility.getInstance().clearDate();
  };
  const saveSelectedDate = async date => {
    await Utility.getInstance().saveSelectedDate(date);
  };
  useEffect(() => {
    if (userData) {
      let client_code_Status = userData?.client_code == '' ? false : true;
      setImageUri(userData.image);
      setClientStatus(userData);
      setClientStatus(client_code_Status);
      setToolTipData(
        client_code_Status
          ? dummyContent.prefusionClientScope
          : dummyContent.nonPrefusionClientScope,
      );
      userId = userData.id;
    }
    const unsubscribe = navigation.addListener('focus', () => {
      if (userData) {
        setImageUri(userData.image);
      }
    });
    if (userData) {
      setImageUri(userData.image);
    }

    return () => {
      unsubscribe;
    };
  }, [imageUri, userData]);

  const getLocationInformation = async () => {
    let locationData = await Utility.getInstance().getStoreData(
      strings.location_data,
    );
    if (locationData) {
      updateUserLocation(locationData);
    }
  };

  const updateUserLocation = locationData => {
    setLoading(true);
    let payload = {uid: userId, location_details: locationData};
    dispatch(updateUserInformationRequest(payload, onS, onF));
  };
  const onS = async resolve => {
    console.log('updateUserLocation`==', resolve);
    setLoading(false);
  };
  const onF = async reject => {
    setLoading(false);
  };
  const scrollToIndexFailed = error => {
    const offset = error.averageItemLength * error.index;
    scrollRef?.current?.scrollToOffset({offset});
    setTimeout(
      () => scrollRef?.current?.scrollToIndex({index: error.index}),
      100,
    ); // You may choose to skip this line if the above typically works well because your average item height is accurate.
  };
  const focusToCurrentDate = () => {
    if (scrollRef != null && scrollRef != undefined) {
      if (scrollRef?.current) {
        if (dateList.length > 0) {
          let index = 1;
          for (let i = 0; i < dateList.length; i++) {
            if (dateValue == dateList[i].date) {
              index = i;
            }
          }
          if (index && index != 0 && index != -1)
            scrollRef?.current?.scrollToIndex({animated: true, index: index});
          // setTimeout(() => {
          //   if (index && index != 0 && index != -1)
          //     scrollRef?.current?.scrollToIndex({animated: true, index: 6});
          // }, 100);
        }
      }
    }
  };

  useEffect(() => {
    if (dateValue) {
      getUserInstance(dateValue);
    }
  }, [dateValue]);

  useEffect(() => {
    getLocationInformation();
  }, []);

  const getUserInstance = async date => {
    let timezone =
      Platform.OS === 'android'
        ? ''
        : Intl.DateTimeFormat().resolvedOptions().timeZone;

    let payload = {
      uid: userId,
      date: date,
      current_date:
        (await Utility.getInstance().getCurrentDateUser()) + ',' + timezone,
    };
    dispatch(weekelyDataRequest(payload, onSSS, onFFF));
  };
  const onSSS = resolve => {
    if (resolve?.data?.goal_type == '' || resolve?.data?.goal_type == null)
      navigation.navigate('AdjustMacros');

    const {fat, veggies, water, carbs, protein, date} = resolve.data;
    global.weekdays = date;
    setFatArray(fat);
    setCarbsArray(carbs);
    setVeggArray(veggies);
    setWaterArray(water);
    setProteinArray(protein);
    setUpdating(!isUpdating);
    setDateList(date);
  };
  // useEffect(() => {
  //   const requestAppTrackingPermission = async () => {
  //     await RNPermissions.request(PERMISSIONS.IOS.APP_TRACKING_TRANSPARENCY)
  //       .then(data => {
  //         console.log('requesting_permission:', data);
  //       })
  //       .catch(error => console.log('error_requesting_permission', error));
  //   };
  //   requestAppTrackingPermission();
  // }, []);

  useEffect(() => {
    if (dateList) {
      if (dateList.length > 0) focusToCurrentDate();
    }
  }, [dateList]);
  const onFFF = reject => {
    if (reject == 'Please Select your Goal First!') {
      setTimeout(() => {
        Utility.getInstance().inflateToast('Please Select your Goal First');
      }, 100);
      setTimeout(() => {
        navigation.navigate('AdjustMacros');
      }, 1000);
    }
  };
  const backPress = () => {
    navigation.goBack();
  };
  const onViewPress = () => {
    navigation.navigate('ServingsizeGuide');
  };
  const onUserPress = () => {
    navigation.navigate('Profile');
  };
  const onPrefusionToolTipItemPress = expression => {
    switch (expression) {
      case 0:
        setTip(false);
        navigation.navigate('Profile');
        break;
      case 1:
        setTip(false);
        navigation.navigate('Chat', 0);
        break;
      case 2:
        setTip(false);
        navigation.navigate('MyGoal');
        break;
      case 3:
        setTip(false);
        navigation.navigate('ProgressReport');
        break;
      case 4:
        setTip(false);
        navigation.navigate('MealHistory');
        break;
      case 5:
        setTip(false);
        navigation.navigate('ApprovedFoods');

        break;

      case 6:
        setTip(false);
        navigation.navigate('BrowseOurRecipies');

        break;
      case 7:
        setTip(false);
        navigation.navigate('ServingsizeGuide');

        break;

      case 8:
        setTip(false);
        navigation.navigate('Setting', 0);
        break;
      case 9:
        setTip(false);

        navigation.navigate('Help', {
          LINK: api.HELP_GUIDE,
        });
        break;
      case 10:
        setToolTipData(dummyContent.prefusionClientScopeWithResources);
        break;

      case 11:
        setTip(false);
        navigation.navigate('HelpWebview');
        break;
      case 12:
        setTip(false);
        navigation.navigate('NationalWebview');
        break;
      default:
    }
  };
  const onNonPrefusionToolTipPress = expression => {
    switch (expression) {
      case 0:
        setTip(false);
        navigation.navigate('Profile');
        break;
      case 1:
        setTip(false);
        navigation.navigate('Chat', 0);
        break;
      case 2:
        setTip(false);
        navigation.navigate('MyGoal');
        break;
      case 3:
        setTip(false);
        navigation.navigate('Setting');

        break;

      case 4:
        setTip(false);
        navigation.navigate('AdjustMacros');

        break;
      case 5:
        setTip(false);
        navigation.navigate('ProgressReport');

        break;
      case 6:
        setTip(false);
        navigation.navigate('MealHistory');

        break;
      case 7:
        setTip(false);
        navigation.navigate('ApprovedFoods');

        break;

      case 8:
        setTip(false);
        navigation.navigate('BrowseOurRecipies');

        break;

      case 9:
        setTip(false);
        navigation.navigate('ServingsizeGuide');

        break;

      case 10:
        setTip(false);
        navigation.navigate('Help', {
          LINK: api.HELP,
        });
        break;

      case 11:
        setTip(false);
        navigation.navigate('Help', {
          LINK: api.HELP,
        });
        break;
      case 12:
        setToolTipData(dummyContent.nonPrefusionClientScopeWithResources);
        break;
      case 13:
        setTip(false);
        navigation.navigate('HelpWebview');
      case 14:
        setTip(false);
        navigation.navigate('NationalWebview');
        break;
      default:
    }
  };
  const Menu = () => {
    return (
      <Tooltip
        backgroundColor="transparent"
        tooltipStyle={{padding: 0, margin: 0}}
        isVisible={showTip}
        ref={toolTipRef}
        contentStyle={{backgroundColor: '#5C5C5C'}}
        content={ToolTipContent()}
        onClose={() => setTip(false)}
        placement="bottom"
        topAdjustment={
          Platform.OS === 'android' ? Utility.getInstance().heightToDp(0.9) : 0
        }>
        <Pressable
          onPress={() => [
            setToolTipData(
              isPrefusionClient
                ? dummyContent.prefusionClientScope
                : dummyContent.nonPrefusionClientScope,
            ),
            setTip(true),
          ]}
          style={styles.menu}>
          <Image style={globalStyles.backimg} source={images.HOME.MENU}></Image>
        </Pressable>
      </Tooltip>
    );
  };
  const ToolTipContent = () => {
    return (
      <View
        style={[
          styles.tooltipc,
          {height: Utility.getInstance().heightToDp(129)},
        ]}>
        <Text
          style={[
            styles.menutext,
            styles.green,
            globalStyles.textAlignCenter,
            globalStyles.font20,
          ]}>
          Navigator
        </Text>
        <FlatList
          showsVerticalScrollIndicator={false}
          data={tooltipData}
          ref={flatlistRef}
          contentContainerStyle={{paddingVertical: 20}}
          keyExtractor={item => item.toString() + 0.7}
          renderItem={renderToolTipItem}></FlatList>
      </View>
    );
  };
  const renderToolTipItem = item => {
    return (
      <>
        {item.item != 'My Blood Work' ? (
          <TouchableOpacity
            onPress={() =>
              isPrefusionClient
                ? onPrefusionToolTipItemPress(item.index)
                : onNonPrefusionToolTipPress(item.index)
            }
            style={styles.menuitem}>
            {item?.item == 'HealthLine' ||
            item?.item == 'National Library of Medicine' ? (
              <Text
                style={{
                  alignSelf: 'center',
                  justifyContent: 'center',
                  color: colors.secondary,
                  fontSize: 18,
                }}>
                {'\u2022'}
                <Text
                  style={[
                    styles.menutext,
                    {color: colors.secondary, paddingLeft: 20},
                  ]}>
                  {`  ` + item.item}
                </Text>
              </Text>
            ) : (
              <Text style={styles.menutext}>{item.item}</Text>
            )}
          </TouchableOpacity>
        ) : null}
      </>
    );
  };
  const DateView = () => {
    return (
      <FlatList
        horizontal
        style={{marginTop: 15}}
        renderItem={renderDates}
        extraData={dateValue}
        ref={scrollRef}
        onScrollToIndexFailed={scrollToIndexFailed}
        keyExtractor={item => item.toString() + 2.9}
        contentContainerStyle={{paddingHorizontal: 20}}
        showsHorizontalScrollIndicator={false}
        data={dateList}></FlatList>
    );
  };
  const renderDates = item => {
    const {show_date, date} = item.item;
    return (
      <Pressable
        onPress={() => [
          setDate(date),
          getUserInstance(date),
          saveSelectedDate(date),
        ]}
        style={[
          styles.dateView_,
          {
            borderWidth: dateValue == date ? 2 : 0.3,
          },
        ]}
        key={item?.index}>
        <Text
          style={[
            styles.headingT,
            {color: dateValue == date ? colors.white : colors.gray},
          ]}>
          {show_date}
        </Text>
      </Pressable>
    );
  };
  const CounterView = () => {
    return (
      <Pressable
        onPress={onViewPress}
        //style={{borderColor: 'green', borderWidth: 2, padding: 15, margin: 10}}
      >
        {/* <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            paddingHorizontal: 40,
          }}>
          <Text
            style={[styles.forgot_pass_heading, styles.whydesc, styles.redC]}>
            {`Carbs: 20g`}
          </Text>
          <Text
            style={[styles.forgot_pass_heading, styles.whydesc, styles.green]}>
            {`Protein: 20g`}
          </Text>
          <Text
            style={[styles.forgot_pass_heading, styles.whydesc, styles.blue]}>
            {`Water: 8oz`}
          </Text>
        </View> */}
        {/* <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            paddingHorizontal: Utility.getInstance().widthToDp(20),
          }}>
          <Text
            style={[styles.forgot_pass_heading, styles.whydesc, styles.orange]}>
            {`Fats: 10g`}
          </Text>

          <Text
            style={[styles.forgot_pass_heading, styles.whydesc, styles.green]}>
            {`Veggies: 1 Cup`}
          </Text>
        </View> */}
        <Text
          onPress={() =>
            navigation.navigate('Help', {
              LINK: api.BUCKER_SERV_SYS,
            })
          }
          style={[
            styles.forgot_pass_heading,
            styles.whydesc,
            {textAlign: 'center', textDecorationLine: 'underline'},
          ]}>
          {`BUCKET SERVING SYSTEM`}
        </Text>
      </Pressable>
    );
  };
  const AddView = () => {
    return (
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'center',
          alignItems: 'center',
          height: 70,
          paddingHorizontal: 0,
        }}>
        <TouchableOpacity
          onPress={() => [
            setDate(moment(today).format('L')),
            navigation.navigate('AddVeg'),
          ]}
          style={[styles.addView_green]}>
          <Text style={styles.headingtext}>Add Veggies</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navigation.navigate('DailyBioFeedback')}
          style={styles.addView_orange}>
          <Text style={[styles.headingtextBlack]}>Daily Feedback</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => [
            setDate(moment(today).format('L')),
            navigation.navigate('AddWater'),
          ]}
          style={styles.addView_blue}>
          <Text style={styles.headingtext}>Add Water</Text>
        </TouchableOpacity>
      </View>
    );
  };

  const CarbsBucketView = () => {
    return (
      <View
        style={{
          justifyContent: 'center',
          flexDirection: 'row',
          paddingHorizontal: 20,
          paddingVertical: 20,
          flex: 1,
        }}>
        <View style={{flex: 0.25}}>
          <Text
            style={[styles.forgot_pass_heading, styles.whydesc, styles.redC]}>
            {`Carbs:`}
          </Text>
        </View>

        <View style={{flex: 0.75}}>
          <FlatList
            data={carbsArray}
            numColumns={6}
            extraData={isUpdating}
            contentContainerStyle={{alignItems: 'flex-start'}}
            renderItem={renderCarbsItem}></FlatList>
        </View>
      </View>
    );
  };
  const renderCarbsItem = item => {
    if (item?.item?.value == 100) {
      return (
        <Image
          style={styles.bucketImg}
          source={
            item?.item?.is_maximize
              ? images.MAXIMIZE_IMAGE.MAXIMUM
              : images.CARBS_IMAGE.CARBS_100
          }></Image>
      );
    } else if (item?.item?.value == 75)
      return (
        <Image
          style={styles.bucketImg}
          source={
            item?.item?.is_maximize
              ? images.MAXIMIZE_IMAGE.MAXIMUM
              : images.CARBS_IMAGE.CARBS_75
          }></Image>
      );
    else if (item?.item?.value == 50)
      return (
        <Image
          style={styles.bucketImg}
          source={
            item?.item?.is_maximize
              ? images.MAXIMIZE_IMAGE.MAXIMUM
              : images.CARBS_IMAGE.CARBS_50
          }></Image>
      );
    else if (item?.item?.value == 25)
      return (
        <Image
          style={styles.bucketImg}
          source={
            item?.item?.is_maximize
              ? images.MAXIMIZE_IMAGE.MAXIMUM
              : images.CARBS_IMAGE.CARBS_25
          }></Image>
      );
    else if (item?.item?.value == 0)
      return (
        <Image
          style={styles.bucketImg}
          source={
            item?.item?.is_maximize
              ? images.MAXIMIZE_IMAGE.MAXIMUM
              : images.APP.RED_EMPTY
          }></Image>
      );
    else {
      return null;
    }
  };

  const FatBucketView = () => {
    return (
      <View
        style={{
          justifyContent: 'space-between',
          flexDirection: 'row',

          paddingHorizontal: 20,
          paddingVertical: 20,
          flex: 1,
        }}>
        <View style={{flex: 0.25}}>
          <Text
            style={[styles.forgot_pass_heading, styles.whydesc, styles.orange]}>
            {`Fats:`}
          </Text>
        </View>

        <View style={{flex: 0.75}}>
          <FlatList
            data={fatArray}
            numColumns={6}
            extraData={isUpdating}
            contentContainerStyle={{alignItems: 'flex-start'}}
            renderItem={renderFatItem}></FlatList>
        </View>
      </View>
    );
  };
  const renderFatItem = item => {
    if (item?.item?.value == 100) {
      return (
        <Image
          style={styles.bucketImg}
          source={
            item?.item?.is_maximize
              ? images.MAXIMIZE_IMAGE.MAXIMUM
              : images.FAT_IMAGE.ORANGE_100
          }></Image>
      );
    } else if (item?.item?.value == 75)
      return (
        <Image
          style={styles.bucketImg}
          source={
            item?.item?.is_maximize
              ? images.MAXIMIZE_IMAGE.MAXIMUM
              : images.FAT_IMAGE.ORANGE_75
          }></Image>
      );
    else if (item?.item?.value == 50)
      return (
        <Image
          style={styles.bucketImg}
          source={
            item?.item?.is_maximize
              ? images.MAXIMIZE_IMAGE.MAXIMUM
              : images.FAT_IMAGE.ORANGE_50
          }></Image>
      );
    else if (item?.item?.value == 25)
      return (
        <Image
          style={styles.bucketImg}
          source={
            item?.item?.is_maximize
              ? images.MAXIMIZE_IMAGE.MAXIMUM
              : images.FAT_IMAGE.ORANGE_25
          }></Image>
      );
    else if (item?.item?.value == 0)
      return (
        <Image
          style={styles.bucketImg}
          source={
            item?.item?.is_maximize
              ? images.MAXIMIZE_IMAGE.MAXIMUM
              : images.APP.ORANGE_EMPTY
          }></Image>
      );
  };
  const ProteinBucketView = () => {
    return (
      <View
        style={{
          justifyContent: 'space-between',
          flexDirection: 'row',
          // alignItems: 'center',
          paddingHorizontal: 20,
          paddingVertical: 20,
          flex: 1,
        }}>
        <View style={{flex: 0.25}}>
          <Text
            style={[styles.forgot_pass_heading, styles.whydesc, styles.green]}>
            {`Protein:`}
          </Text>
        </View>

        <View style={{flex: 0.75}}>
          <FlatList
            numColumns={6}
            data={proteinArray}
            extraData={isUpdating}
            contentContainerStyle={{alignItems: 'flex-start'}}
            renderItem={rendeProteinItem}></FlatList>
        </View>
      </View>
    );
  };
  const rendeProteinItem = item => {
    if (item?.item?.value == 100) {
      return (
        <Image
          style={styles.bucketImg}
          source={
            item?.item?.is_maximize
              ? images.MAXIMIZE_IMAGE.MAXIMUM
              : images.PROTEIN_IMAGE.PROTEIN_100
          }></Image>
      );
    } else if (item?.item?.value == 75)
      return (
        <Image
          style={styles.bucketImg}
          source={
            item?.item?.is_maximize
              ? images.MAXIMIZE_IMAGE.MAXIMUM
              : images.PROTEIN_IMAGE.PROTEIN_75
          }></Image>
      );
    else if (item?.item?.value == 50)
      return (
        <Image
          style={styles.bucketImg}
          source={
            item?.item?.is_maximize
              ? images.MAXIMIZE_IMAGE.MAXIMUM
              : images.PROTEIN_IMAGE.PROTEIN_50
          }></Image>
      );
    else if (item?.item?.value == 25)
      return (
        <Image
          style={styles.bucketImg}
          source={
            item?.item?.is_maximize
              ? images.MAXIMIZE_IMAGE.MAXIMUM
              : images.PROTEIN_IMAGE.PROTEIN_25
          }></Image>
      );
    else if (item?.item?.value == 0)
      return (
        <Image
          style={styles.bucketImg}
          source={
            item?.item?.is_maximize
              ? images.MAXIMIZE_IMAGE.MAXIMUM
              : images.APP.GREEN_EMPTY
          }></Image>
      );
  };
  const WaterBucketView = () => {
    return (
      <View
        style={{
          justifyContent: 'space-between',
          flexDirection: 'row',
          // alignItems: 'center',
          paddingHorizontal: 20,
          paddingVertical: 20,
          flex: 1,
        }}>
        <View style={{flex: 0.25}}>
          <Text
            style={[styles.forgot_pass_heading, styles.whydesc, styles.blue]}>
            {`Water:`}
          </Text>
        </View>
        <View style={{flex: 0.75}}>
          <FlatList
            data={waterArray}
            numColumns={6}
            extraData={isUpdating}
            contentContainerStyle={{alignItems: 'flex-start'}}
            renderItem={renderWaterItem}></FlatList>
        </View>
      </View>
    );
  };
  const renderWaterItem = item => {
    if (item.item == 100) {
      return (
        <Image
          style={styles.bucketImg}
          source={images.WATER_IMAGE.WATER_100}></Image>
      );
    } else if (item.item == 75)
      return (
        <Image
          style={styles.bucketImg}
          source={images.WATER_IMAGE.WATER_75}></Image>
      );
    else if (item.item == 50)
      return (
        <Image
          style={styles.bucketImg}
          source={images.WATER_IMAGE.WATER_50}></Image>
      );
    else if (item.item == 25)
      return (
        <Image
          style={styles.bucketImg}
          source={images.WATER_IMAGE.WATER_25}></Image>
      );
    else if (item.item == 0)
      return (
        <Image style={styles.bucketImg} source={images.APP.BLUE_EMPTY}></Image>
      );
  };
  const VeggiesBucketView = () => {
    return (
      <View
        style={{
          justifyContent: 'space-between',
          flexDirection: 'row',

          paddingHorizontal: 20,
          paddingVertical: 20,
          flex: 1,
        }}>
        <View style={{flex: 0.25}}>
          <Text
            style={[styles.forgot_pass_heading, styles.whydesc, styles.green]}>
            {`Veggies:`}
          </Text>
          <Text style={styles.requireText}>
            log each 1 cup serving by itself
          </Text>
        </View>
        <View style={{flex: 0.75}}>
          <FlatList
            data={veggiesArray}
            numColumns={6}
            extraData={isUpdating}
            contentContainerStyle={{alignItems: 'flex-start'}}
            renderItem={renderVegItem}></FlatList>
        </View>
      </View>
    );
  };
  const renderVegItem = item => {
    if (item.item == 100) {
      return (
        <Image
          style={styles.bucketImg}
          source={images.VEG_IMAGE.VEG_100}></Image>
      );
    } else if (item.item == 75)
      return (
        <Image
          style={styles.bucketImg}
          source={images.VEG_IMAGE.VEG_75}></Image>
      );
    else if (item.item == 50)
      return (
        <Image
          style={styles.bucketImg}
          source={images.VEG_IMAGE.VEG_50}></Image>
      );
    else if (item.item == 25)
      return (
        <Image
          style={styles.bucketImg}
          source={images.VEG_IMAGE.VEG_25}></Image>
      );
    else if (item.item == 0)
      return (
        <Image
          style={styles.bucketImg}
          source={images.APP.VEGGIE_EMPTY}></Image>
      );
  };
  const BottomTabMenu = () => {
    return (
      <View style={globalStyles.bottom_tab_c}>
        <TouchableOpacity
          onPress={() => navigation.navigate('MyGoal')}
          style={globalStyles.bottom_tab_item_c}>
          <Image
            source={images.APP.GOAL}
            style={[
              globalStyles.bottom_tab_item_img,
              {tintColor: colors.white},
            ]}
          />
          <Text style={[globalStyles.bottom_tab_text, {color: colors.white}]}>
            Goals
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => navigation.navigate('AddMeal')}
          style={globalStyles.bottom_tab_item_c}>
          <Text
            style={[
              globalStyles.bottom_tab_text,
              {marginTop: -10, color: colors.white},
            ]}>
            Add Meal
          </Text>
          <View style={globalStyles.bottom_tab_addmeal_c}>
            <Image
              source={images.SIGNUP.PLUS}
              style={[
                globalStyles.bottom_tab_item_img_plus,
                {tintColor: colors.secondary},
              ]}
            />
          </View>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => navigation.navigate('ProgressReport')}
          style={globalStyles.bottom_tab_item_c}>
          <Image
            source={images.APP.PROGRESS}
            style={[
              globalStyles.bottom_tab_item_img,
              {tintColor: colors.white},
            ]}
          />
          <Text style={[globalStyles.bottom_tab_text, {color: colors.white}]}>
            Progress
          </Text>
        </TouchableOpacity>
      </View>
    );
  };
  const DefautView = () => {
    return (
      <>
        <View style={[styles.flex, {backgroundColor: colors.primary}]}>
          <Loader isLoading={userWeeklyInstanceIsLoading || isLoading}></Loader>
          <View style={styles.appHeader}>
            {Menu()}
            <TouchableOpacity onPress={backPress}>
              <Image
                style={globalStyles.applogoheader}
                source={images.FAVORITE.APPLOGO}></Image>
            </TouchableOpacity>
            <TouchableOpacity onPress={onUserPress}>
              <Image
                style={styles.userlogo_image}
                source={{uri: imageUri}}></Image>
            </TouchableOpacity>
          </View>

          <ScrollView showsVerticalScrollIndicator={false}>
            {DateView()}
            <CounterView />
            {/* <Text onPress={onViewPress} style={styles.guideT}>
              {strings.viewguide}
            </Text> */}

            <View style={{paddingHorizontal: 20}}>{AddView()}</View>
            <Text style={styles.bucketSize}>{strings.bSizeguide}</Text>
            <View style={styles.progressc}>
              <View style={styles.progressbar}>
                <GradientCircularProgress
                  startColor={colors.primary}
                  middleColor={colors.secondary}
                  endColor={colors.primary}
                  size={67}
                  emptyColor={colors.black}
                  progress={
                    userWeeklyInstance && userWeeklyInstance.filled_data_value
                  }
                  strokeWidth={6}>
                  <Text style={styles.lbs}>
                    {userWeeklyInstance && userWeeklyInstance.filled}
                  </Text>
                </GradientCircularProgress>
                <Text style={[styles.bucketSize, globalStyles.mt_10]}>
                  {strings.filledbucket}
                </Text>
              </View>
              <View style={styles.progressbar}>
                <GradientCircularProgress
                  startColor={colors.primary}
                  middleColor={colors.secondary}
                  endColor={colors.primary}
                  size={67}
                  emptyColor={colors.black}
                  progress={
                    userWeeklyInstance &&
                    userWeeklyInstance.remaining_data_value
                  }
                  strokeWidth={6}>
                  <Text style={styles.lbs}>
                    {userWeeklyInstance && userWeeklyInstance.remaining}
                  </Text>
                </GradientCircularProgress>
                <Text style={[styles.bucketSize, globalStyles.mt_10]}>
                  {strings.remainingbucket}
                </Text>
              </View>
            </View>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'center',
                alignItems: 'center',
                padding: 0,
              }}>
              <TouchableOpacity
                onPress={() => [
                  setDate(moment(today).format('L')),
                  navigation.navigate('DailyDairy'),
                ]}
                style={[styles.dailydairy_btn]}>
                <Text style={styles.headingtext}>{strings.dairy}</Text>
              </TouchableOpacity>
            </View>

            {CarbsBucketView()}
            {FatBucketView()}
            {ProteinBucketView()}
            {WaterBucketView()}
            {VeggiesBucketView()}
          </ScrollView>
          {BottomTabMenu()}
        </View>
      </>
    );
  };

  return DefautView();
};
export default Home;
