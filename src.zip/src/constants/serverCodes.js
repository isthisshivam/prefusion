export default {
  success: 200,
  error: 400,
  one: 1,
};
