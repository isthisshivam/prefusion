export default {
  fc_server_key:
    'AAAAv2ohSvI:APA91bFsI7vsuzzsszhWa39bs1qeTb_nnanlsl7fJjHMLQugGsq0Azs1uTYw2wDu5yq7DFsS-9D98kKrUJqEgjC9c1Ehfy_PdpaIVfi8yUtVlQJ16T28-vA18dKAwC8aDmg6bNsJuRek',
  apiKey: 'AIzaSyD610hatTmZThjMwEVgJ83b27oeOPJ5y6I',
  authDomain: 'prefusion-app.firebaseapp.com',
  projectId: 'prefusion-app',
  storageBucket: 'prefusion-app.appspot.com',
  messagingSenderId: '715029960105',
  appId: '1:715029960105:web:95aada9d5ea0abb722a0b8',
  measurementId: 'G-GT7EGFZ9NP',
};
