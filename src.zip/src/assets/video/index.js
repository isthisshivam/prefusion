export default {
  SPLASHVIDEO: require('../video/splashVideo.mp4'),
  LOGINVIDEO: require('../video/signUpVideo.mp4'),
};
