import * as Actions from './index';

// init progressReportInfo
export function progressInfoRequest(obj, onSuccess, onFailure) {
  return {
    type: Actions.PROGRESS_INFORMATION_REQUEST,
    payload: {
      obj,
    },
    onSuccess,
    onFailure,
  };
}

// progressReportInfo success
export function progressInfoSuccess(userData, onSuccess, onFailure) {
  return {
    type: Actions.PROGRESS_INFORMATION_SUCCESS,
    payload: {
      userData,
    },
    onSuccess,
    onFailure,
  };
}

// progressReportInfo fail
export function progressInfoFailure(userData, onSuccess, onFailure) {
  return {
    type: Actions.PROGRESS_INFORMATION_FAILURE,
    payload: {
      userData,
    },
    onSuccess,
    onFailure,
  };
}
