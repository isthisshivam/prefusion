import * as ActionType from '../action/index';
import {takeLatest, call, put} from 'redux-saga/effects';
import {
  progressInfoSuccess,
  progressInfoFailure,
} from '../action/ProgressReportAction';
import ApiConstant from '../../constants/api';
import {postRequest, postRequestFormData} from '../webservice/webServiceCall';

function* progressReportInfoModule(data) {
  try {
    const Data = yield call(
      postRequest,
      ApiConstant.BASE_URL + ApiConstant.PROGRESS_REPORT_INFO,
      data.payload.obj,
    );
    yield put(progressInfoSuccess(Data));
    data.onSuccess(Data);
  } catch (error) {
    yield put(progressInfoFailure());
    data.onFailure(error);
  }
}

export default function* progressReportInfoSaga() {
  yield takeLatest(
    ActionType.PROGRESS_INFORMATION_REQUEST,
    progressReportInfoModule,
  );
}
