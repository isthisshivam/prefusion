import React, {useState, useEffect, useRef, useLayoutEffect} from 'react';
import {
  View,
  Text,
  ImageBackground,
  TouchableOpacity,
  Image,
  ScrollView,
  FlatList,
  Pressable,
  StatusBar,
  BackHandler,
} from 'react-native';
import images from '../assets/images';
import strings from '../constants/strings';
import globalStyles from '../assets/globalStyles';
const Carbs = props => {
  console.log('props=>', props);
  const {value} = props;
  if (value == 100) {
    return (
      <Image
        style={globalStyles.bucketImg}
        source={images.CARBS_IMAGE.CARBS_100}></Image>
    );
  } else if (value == 75)
    return (
      <Image
        style={globalStyles.bucketImg}
        source={images.CARBS_IMAGE.CARBS_75}></Image>
    );
  else if (value == 50)
    return (
      <Image
        style={globalStyles.bucketImg}
        source={images.CARBS_IMAGE.CARBS_50}></Image>
    );
  else if (value == 25)
    return (
      <Image
        style={globalStyles.bucketImg}
        source={images.CARBS_IMAGE.CARBS_25}></Image>
    );
  else if (value == 0)
    return (
      <Image
        style={globalStyles.bucketImg}
        source={images.APP.RED_EMPTY}></Image>
    );
};

export default Carbs;
