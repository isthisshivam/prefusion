import React from 'react';
import {
  ImageBackground,
  View,
  Text,
  Button,
  ActivityIndicator,
  TouchableOpacity,
  Image,
} from 'react-native';

import styles from '../container/Chat/style';
import moment from 'moment';
import images from '../assets/images';
const Message = props => {
  const {
    receiver_image,
    type,
    message,
    sender_id,
    created_at,
    sender_profile,
    receiver_id,
    image,
    mode,
    userId,
    side,
  } = props;

  if (side == 'right') {
    return (
      <View style={styles.left_msg_c}>
        <Image
          source={sender_profile ? {uri: sender_profile} : images.FAVORITE.USER}
          style={styles.sender_img}></Image>
        <View>
          <Text style={styles.left_msg_time}>
            {moment(created_at).calendar()}
          </Text>
          {type == 'text' && (
            <View style={styles.left_msg}>
              <Text>{message}</Text>
            </View>
          )}
          {type == 'image' && (
            <ImageBackground
              style={{height: 200, width: 200}}
              imageStyle={{borderRadius: 10}}
              resizeMode="cover"
              source={{uri: image?.uri}}></ImageBackground>
          )}
        </View>
      </View>
    );
  } else {
    return (
      <View style={styles.right_msg_c}>
        <View style={styles.right_msg_c_c}>
          <Text style={styles.right_msg_text}>
            {moment(created_at).calendar()}
          </Text>
          {type == 'text' && (
            <View style={styles.right_msg}>
              <Text>{message}</Text>
            </View>
          )}

          {type == 'image' && image != '' && (
            <ImageBackground
              style={{height: 200, width: 200, margin: 5}}
              imageStyle={{borderRadius: 10}}
              resizeMode="cover"
              source={{uri: image?.uri}}></ImageBackground>
          )}
        </View>

        <Image
          source={sender_profile ? {uri: sender_profile} : images.FAVORITE.USER}
          style={styles.sender_img}></Image>
      </View>
    );
  }
};
export default Message;
